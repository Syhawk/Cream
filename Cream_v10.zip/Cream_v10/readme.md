需要安装依赖：
lmdb leveldb protobuf glog boost