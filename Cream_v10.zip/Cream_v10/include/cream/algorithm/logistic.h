#ifndef CREAM_ALGORITHM_LOGISTIC_H
#define CREAM_ALGORITHM_LOGISTIC_H

#include <vector>
#include <string>

#include "cream/cream.h"
#include "cream/algorithm/logistic_candy.h"

namespace cream {

using std::vector;
using std::string;


/**
 * @brief logistic: machine learning algorithm.
 */
template <typename Dtype>
class Logistic: public Cream<Dtype> {
public:
  explicit Logistic(const SolverParameter& param)
      : Cream<Dtype>(param) { }

  virtual void init();
  virtual inline const char* type() const { return "Logistic"; }

private:
  void loss(const string& label, const vector<pair<Dtype, string>>& top_n);
  void update_weight(size_t idx_x, size_t idx_w);
  void train_one_epoch();
  Dtype regularization(Dtype val);

  LogisticParameter _logistic_param;

  DISABLE_COPY_AND_ASSIGN(Logistic);
};

}  // namespace cream

#endif  // CREAM_ALGORITHM_LOGISTIC_H
