#ifndef CREAM_ALGORITHM_LOGISTIC_CANDY_H
#define CREAM_ALGORITHM_LOGISTIC_CANDY_H

#include "cream/common.h"
#include "cream/candy.h"

namespace cream {

/**
 * @brief For logistic storage data.
 */
template <typename Dtype>
class LogisticCandy : public Candy<Dtype> {
public:
  explicit LogisticCandy() {}

  void init_other_param();

private:
  DISABLE_COPY_AND_ASSIGN(LogisticCandy);
};

}  // namespace cream

#endif  // CREAM_ALGORITHM_LOGISTIC_CANDY_H
