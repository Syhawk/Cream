#ifndef CREAM_ALGORITHM_KMEANS_CANDY_H
#define CREAM_ALGORITHM_KMEANS_CANDY_H

#include <string>
#include <vector>

#include "cream/common.h"
#include "cream/candy.h"

namespace cream {

/**
 * @brief For k_means storage data.
 */
template <typename Dtype>
class KMeansCandy : public Candy<Dtype> {
public:
  explicit KMeansCandy() {}

  void init_other_param();

private:
  DISABLE_COPY_AND_ASSIGN(KMeansCandy);
};

}  // namespace cream

#endif  // CREAM_ALGORITHM_KMEANS_CANDY_H
