#ifndef CREAM_ALGORITHM_HASHCODE_CANDY_H
#define CREAM_ALGORITHM_HASHCODE_CANDY_H

#include "cream/proto/cream.pb.h"
#include "cream/candy.h"

namespace cream {

/**
 * @brief For hashcode storage data.
 */
template <typename Dtype>
class HashcodeCandy : public Candy<Dtype> {
public:
  explicit HashcodeCandy() {}

private:
  DISABLE_COPY_AND_ASSIGN(HashcodeCandy);
};

}  // namespace cream

#endif  // CREAM_ALGORITHM_HASHCODE_CANDY_H
