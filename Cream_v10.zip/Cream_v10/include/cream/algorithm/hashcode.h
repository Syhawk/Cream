#ifndef CREAM_ALGORITHM_HASHCODE_H
#define CREAM_ALGORITHM_HASHCODE_H

#include <string>
#include <vector>

#include "cream/cream.h"
#include "cream/common.h"
#include "cream/algorithm/hashcode_candy.h"

namespace cream {

/**
 * @brief hashcode: machine learning algorithm.
 */
template <typename Dtype>
class Hashcode: public Cream<Dtype> {
public:
  explicit Hashcode(const SolverParameter& param)
      : Cream<Dtype>(param) { }

  virtual void init();
  virtual void train();
  virtual void test();
  virtual inline const char* type() const { return "Hashcode"; }

private:
  void calculate_hashcode();
  void generate_hashcode_by_mean_value();
  void generate_hashcode_by_feature_value();

  HashcodeParameter _hashcode_param;

  DISABLE_COPY_AND_ASSIGN(Hashcode);
};

}  // namespace cream

#endif  // CREAM_ALGORITHM_HASHCODE_H
