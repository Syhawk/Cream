#ifndef CREAM_ALGORITHM_KMEANS_H
#define CREAM_ALGORITHM_KMEANS_H

#include <string>
#include <vector>

#include "cream/cream.h"
#include "cream/algorithm/k_means_candy.h"

namespace cream {

/**
 * @brief k_means: machine learning algorithm.
 */
template <typename Dtype>
class KMeans: public Cream<Dtype> {
public:
  explicit KMeans(const SolverParameter& param)
      : Cream<Dtype>(param) { }

  virtual void init();
  virtual inline const char* type() const { return "KMeans"; }

private:
  void train_one_epoch();
  void loss(size_t idx_x, size_t idx_p);
  void update_weight();
  void get_index_to_label(const vector<pair<Dtype, string>>& top_n,
                          int label_index);

  KMeansParameter _k_means_param;

  DISABLE_COPY_AND_ASSIGN(KMeans);
};

}  // namespace cream

#endif  // CREAM_ALGORITHM_KMEANS_H
