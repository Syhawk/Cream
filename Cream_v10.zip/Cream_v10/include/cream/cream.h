#ifndef CREAM_CREAM_H
#define CREAM_CREAM_H

#include <algorithm>
#include <string>
#include <vector>
#include <utility>
#include <boost/shared_ptr.hpp>

#include "cream/proto/cream.pb.h"
#include "cream/candy.h"
#include "cream/cream_factory.hpp"

namespace cream {

using std::pair;
using std::string;
using std::vector;
using boost::shared_ptr;


template <typename Dtype>
class Cream {
public:
  explicit Cream(const SolverParameter& param)
    : _param(param),
      _epoch(1),
      _rate(Dtype(1)),
      _in_accuracy(0),
      _out_accuracy(0),
      _h_x(Dtype(0)),
      _loss(Dtype(0)) {}
  virtual ~Cream() {}

  virtual void init() {}
  virtual void train();
  virtual void test();
  virtual inline const char* type() const { return ""; }

protected:
  // The learning rate decay policy. The currently implemented learning rate
  // policies are as follows:
  //    - fixed: always return base_lr.
  //    - step: return base_lr * step_gamma ^ (floor(epoch / step_epoch))
  //    - exp: return base_lr * exp_gamma ^ epoch
  //    - inv: return base_lr * (1 + inv_gamma * epoch) ^ (- inv_power)
  //    - multistep: return base_lr * multistep_gamma ^ epoch
  //    - poly: the effective learning rate follows a polynomial decay, to be
  //      zero by the max_iter. return base_lr (1 - epoch/train_epoch) ^ (ploy_power)
  //    - sigmoid: the effective learning rate follows a sigmod decay
  //      return base_lr * (1 / (1 + exp(-sigmoid_gamma * (epoch - sigmoid_epoch))))
  //
  virtual void generate_learning_rate();
  virtual void shuffle();
  virtual void train_one_epoch() {}
  virtual void test_one_epoch();
  virtual void display();
  virtual void snapshot();

  virtual void h_x(size_t idx_x, size_t idx_w);
  virtual void h_x(const vector<Dtype>& data, const vector<Dtype>& weight);
  virtual void generate_file_path();
  virtual void generate_datums();
  virtual void maintain_top_n(const string& label, vector<pair<Dtype, string>>* top_n);
  virtual void maintain_acc(const vector<pair<Dtype, string>>& top_n,
                              const string& label,
                              long* acc);
  virtual bool is_show(int epoch);
  virtual void show_title();
  virtual void show_lr(int* num);
  virtual void show_loss(int* num);
  virtual void show_acc(int* num);

  SolverParameter _param;
  int _epoch;
  string _file_path;
  vector<Datum> _datums;
  Dtype _rate;
  shared_ptr<Candy<Dtype>> _candy;
  long _in_accuracy;
  long _out_accuracy;
  Dtype _h_x;
  Dtype _loss;

private:
  DISABLE_COPY_AND_ASSIGN(Cream);
};  // class Cream

}  // namespace cream

#endif  // CREAM_CREAM_H
