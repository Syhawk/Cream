#ifndef CREAM_SIMILARITY_HASHCODE_PAPER_MODEL_TEST_H
#define CREAM_SIMILARITY_HASHCODE_PAPER_MODEL_TEST_H

#include <string>
#include <vector>

#include "cream/model_test.h"
#include "cream/similarity/hashcode_model_test.h"

namespace cream {

using std::vector;
using std::string;


class HashcodePaperModelTest : public HashcodeModelTest {
public:
  HashcodePaperModelTest() {
    ModelTest::init();
  }

  void read_feature(const string& path,
                    const string& type,
                    const string& filter,
                    const string& mode,
                    float lambda,
                    const string& sort_mode);

private:
  DISABLE_COPY_AND_ASSIGN(HashcodePaperModelTest);
}; // class HashcodePaperModelTest

} // namespace cream

#endif // CREAM_SIMILARITY_HASHCODE_PAPER_MODEL_TEST_H
