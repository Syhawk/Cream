#ifndef CREAM_CANDY_H
#define CREAM_CANDY_H

#include <string>
#include <vector>
#include <unordered_map>
#include <boost/shared_ptr.hpp>

#include "cream/common.h"
#include "cream/proto/cream.pb.h"

namespace cream {

using std::string;
using std::vector;
using std::pair;
using std::unordered_map;
using boost::shared_ptr;

struct Shape {
  size_t width;
  size_t height;
  size_t channel;
  size_t num;
};

/**
 * @brief For logistic storage data.
 */
template <typename Dtype>
class Candy {
public:
  typedef shared_ptr<vector<shared_ptr<vector<Dtype>>>> Vecs;
  typedef shared_ptr<vector<shared_ptr<string>>> Strs;
  typedef shared_ptr<vector<shared_ptr<vector<size_t>>>> Size_tList;
  typedef shared_ptr<unordered_map<string, size_t>> Maps;

  explicit Candy() {}

  void init(const SolverParameter& param);

  void shuffle();

  const vector<shared_ptr<vector<Dtype>>>& data() {
    return *_data;
  }

  const vector<Dtype>& data(size_t index) {
    return *((*_data)[index]);
  }

  size_t data_size() {
    return _data->size();
  }

  Vecs mutable_data() {
    return _data;
  }

  shared_ptr<vector<Dtype>> mutable_data(size_t index) {
    return (*_data)[index];
  }
  
  void swap_data(size_t a, size_t b) {
    shared_ptr<vector<Dtype>> c((*_data)[a]);
    (*_data)[a] = (*_data)[b];
    (*_data)[b] = c;
  }

  const vector<shared_ptr<vector<Dtype>>>& weight() {
    return *_weight;
  }

  const vector<Dtype>& weight(size_t index) {
    return *((*_weight)[index]);
  }

  size_t weight_size() {
    return _weight->size();
  }

  Vecs mutable_weight() {
    return _weight;
  }

  shared_ptr<vector<Dtype>> mutable_weight(size_t index) {
    return (*_weight)[index];
  }
  
  void swap_weight(size_t a, size_t b) {
    shared_ptr<vector<Dtype>> c((*_weight)[a]);
    (*_weight)[a] = (*_weight)[b];
    (*_weight)[b] = c;
  }
  
  void add_weight(const vector<Dtype>& weight) {
    _weight->push_back(shared_ptr<vector<Dtype>>(new vector<Dtype>(weight)));
  }

  const vector<shared_ptr<string>>& label() {
    return *_label;
  }

  const string& label(size_t index) {
    return *((*_label)[index]);
  }

  size_t label_size() {
    return _label->size();
  }

  shared_ptr<string> mutable_label(size_t index) {
    return (*_label)[index];
  }
  
  void swap_label(size_t a, size_t b) {
    shared_ptr<string> c((*_label)[a]);
    (*_label)[a] = (*_label)[b];
    (*_label)[b] = c;
  }

  const vector<shared_ptr<string>>& path() {
    return *_path;
  }

  const string& path(size_t index) {
    return *((*_path)[index]);
  }

  size_t path_size() {
    return _path->size();
  }

  shared_ptr<string> mutable_path(size_t index) {
    return (*_path)[index];
  }
  
  void swap_path(size_t a, size_t b) {
    shared_ptr<string> c((*_path)[a]);
    (*_path)[a] = (*_path)[b];
    (*_path)[b] = c;
  }

  const string& unique_label(size_t index) {
    return *((*_unique_label)[index]);
  }

  size_t unique_label_size() {
    return _unique_label->size();
  }

  shared_ptr<string> mutable_unique_label(size_t index) {
    return (*_unique_label)[index];
  }

  Strs mutable_unique_label() {
    return _unique_label;
  }
  
  void swap_unique_label(size_t a, size_t b) {
    shared_ptr<string> c((*_unique_label)[a]);
    (*_unique_label)[a] = (*_unique_label)[b];
    (*_unique_label)[b] = c;
  }
  
  void add_unique_label(const string& str) {
    _unique_label->push_back(shared_ptr<string>(new string(str)));
  }

  const Shape& shape() {
    return _shape;
  }

  const vector<shared_ptr<vector<Dtype>>>& test_data() {
    return *_test_data;
  }

  const vector<Dtype>& test_data(size_t index) {
    return *((*_test_data)[index]);
  }

  size_t test_data_size() {
    return _test_data->size();
  }
  
  Vecs mutable_test_data() {
    return _test_data;
  }
  
  shared_ptr<vector<Dtype>> mutable_test_data(size_t index) {
    return _test_data->at(index);
  }

  const vector<shared_ptr<string>>& test_label() {
    return *_test_label;
  }
  
  const string& test_label(size_t index) {
    return *((*_test_label)[index]);
  }

  size_t test_label_size() {
    return _test_label->size();
  }

  const vector<shared_ptr<string>>& test_path() {
    return *_test_path;
  }

  size_t test_path_size() {
    return _test_path->size();
  }

  const Shape& test_shape() {
    return _test_shape;
  }
  
  const vector<shared_ptr<vector<size_t>>>& index_to_data() {
    return *_index_to_data;
  }

  const vector<size_t>& index_to_data(size_t index) {
    return *((*_index_to_data)[index]);
  }

  Size_tList mutable_index_to_data() {
    return _index_to_data;
  }

  size_t index_to_data_size() {
    return _index_to_data->size();
  }
  
  void init_index_to_data() {
    _index_to_data = Size_tList(new vector<shared_ptr<vector<size_t>>>());
  }
  
  void add_index_to_data(const vector<size_t>& indexs) {
    _index_to_data->push_back(shared_ptr<vector<size_t>>(new vector<size_t>(indexs)));
  }

  const unordered_map<string, size_t>& label_to_index() {
    return *_label_to_index;
  }

  const size_t& label_to_index(string key) {
    return (*_label_to_index)[key];
  }

  size_t label_to_index_size() {
    return _label_to_index->size();
  }

  Maps mutable_label_to_index() {
    return _label_to_index;
  }
  
  void init_label_to_index() {
    _label_to_index = Maps(new unordered_map<string, size_t>());
  }

protected:
  virtual void init_other_param() {}

private:
  Vecs _data;
  Vecs _weight;
  Strs _label;
  Strs _path;
  Strs _unique_label;
  Shape _shape;

  Vecs _test_data;
  Strs _test_label;
  Strs _test_path;
  Shape _test_shape;
  
  Size_tList _index_to_data;
  Maps _label_to_index;

  virtual void init_train(const SolverParameter& param);
  virtual void init_test(const SolverParameter& param);
  virtual void init_weight(const SolverParameter& param);

  DISABLE_COPY_AND_ASSIGN(Candy);
};

}  // namespace cream

#endif  // CREAM_CANDY_H
