#ifndef CREAM_MODEL_TEST_H
#define CREAM_MODEL_TEST_H

#include <string>
#include <vector>
#include <utility>

#include "cream/proto/cream.pb.h"

namespace cream {

using std::vector;
using std::string;
using std::pair;


struct Point {
  string label;
  vector<float> weight;
  vector<string> labels;
  vector<string> paths;
  vector<vector<float>> features;
  Point() {}
};

class ModelTest {
public:
  ModelTest() {
    init();
  }

  virtual void init();
  virtual void read_model(const string& path, const string& type);
  virtual void read_feature(const string& path,
                            const string& type,
                            const string& filter,
                            const string& mode,
                            float lambda,
                            const string& sort_mode);
  virtual void read_test_feature(const string& path, const string& type);
  virtual void test(int top_n,
                    const string& space_mode,
                    float space_lambda,
                    const string& space_sort_mode,
                    const string& top_n_mode,
                    float top_n_lambda,
                    const string& top_n_sort_mode);
  virtual void generate_space(const vector<float>& feature,
                              int top_k,
                              const string& space_mode,
                              float space_lambda,
                              const string& space_sort_mode);
  virtual void generate_top_n(const vector<float>& feature,
                              int top_k,
                              const string& top_n_mode,
                              float top_n_lambda,
                              const string& top_n_sort_mode);
  virtual void update_accuracy_and_datums(const string& label, const string& path);
  virtual void show_accuracy(int count, bool is_showed);
  virtual void write_datums(const string& path, const string& type);

protected:
  vector<Point> weights;
  Point test_data;
  vector<pair<int, int>> accuracy;
  vector<pair<float, size_t>> spaces;
  vector<pair<float, pair<string, string>>> top_n;
  vector<Datum> datums;

private:
  DISABLE_COPY_AND_ASSIGN(ModelTest);
}; // class ModelTest

} // namespace cream

#endif // CREAM_MODEL_TEST_H
