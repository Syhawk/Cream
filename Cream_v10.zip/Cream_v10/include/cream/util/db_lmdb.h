#ifndef CREAM_UTIL_DB_LMDB_H
#define CREAM_UTIL_DB_LMDB_H

#include <string>
#include <vector>

#include "lmdb.h"
#include "cream/util/db.h"

namespace cream { namespace db {

using std::string;
using std::vector;

inline void MDB_CHECK(int mdb_status) {
  CHECK_EQ(mdb_status, MDB_SUCCESS) << mdb_strerror(mdb_status);
}

class LMDBCursor : public Cursor {
public:
  explicit LMDBCursor(MDB_txn* mdb_txn, MDB_cursor* mdb_cursor)
    : _mdb_txn(mdb_txn), _mdb_cursor(mdb_cursor), _valid(false) {
    SeekToFirst();
  }
  virtual ~LMDBCursor() {
    mdb_cursor_close(_mdb_cursor);
    mdb_txn_abort(_mdb_txn);
  }
  virtual void SeekToFirst() { Seek(MDB_FIRST); }
  virtual void Next() { Seek(MDB_NEXT); }
  virtual string key() {
    return string(static_cast<const char*>(_mdb_key.mv_data), _mdb_key.mv_size);
  }
  virtual string value() {
    return string(static_cast<const char*>(_mdb_value.mv_data),
        _mdb_value.mv_size);
  }
  virtual bool valid() { return _valid; }

private:
  void Seek(MDB_cursor_op op) {
    int mdb_status = mdb_cursor_get(_mdb_cursor, &_mdb_key, &_mdb_value, op);
    if (mdb_status == MDB_NOTFOUND) {
      _valid = false;
    } else {
      MDB_CHECK(mdb_status);
      _valid = true;
    }
  }

  MDB_txn* _mdb_txn;
  MDB_cursor* _mdb_cursor;
  MDB_val _mdb_key, _mdb_value;
  bool _valid;
};

class LMDBTransaction : public Transaction {
public:
  explicit LMDBTransaction(MDB_env* mdb_env)
    : _mdb_env(mdb_env) { }
  virtual void Put(const string& key, const string& value);
  virtual void Commit();

private:
  MDB_env* _mdb_env;
  vector<string> keys, values;

  void DoubleMapSize();

  DISABLE_COPY_AND_ASSIGN(LMDBTransaction);
};

class LMDB : public DB {
public:
  LMDB() : _mdb_env(NULL) { }
  virtual ~LMDB() { Close(); }
  virtual void Open(const string& source, Mode mode);
  virtual void Close() {
    if (_mdb_env != NULL) {
      mdb_dbi_close(_mdb_env, _mdb_dbi);
      mdb_env_close(_mdb_env);
      _mdb_env = NULL;
    }
  }
  virtual LMDBCursor* NewCursor();
  virtual LMDBTransaction* NewTransaction();

private:
  MDB_env* _mdb_env;
  MDB_dbi _mdb_dbi;
};

}  // namespace db
}  // namespace cream

#endif  // CREAM_UTIL_DB_LMDB_H
