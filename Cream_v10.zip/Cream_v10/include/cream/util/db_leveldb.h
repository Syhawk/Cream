#ifndef CREAM_UTIL_DB_LEVELDB_H
#define CREAM_UTIL_DB_LEVELDB_H

#include <string>

#include "leveldb/db.h"
#include "leveldb/write_batch.h"
#include "cream/util/db.h"

namespace cream { namespace db {

class LevelDBCursor : public Cursor {
public:
  explicit LevelDBCursor(leveldb::Iterator* iter)
    : _iter(iter) {
    SeekToFirst();
    CHECK(_iter->status().ok()) << _iter->status().ToString();
  }
  ~LevelDBCursor() { delete _iter; }
  virtual void SeekToFirst() { _iter->SeekToFirst(); }
  virtual void Next() { _iter->Next(); }
  virtual string key() { return _iter->key().ToString(); }
  virtual string value() { return _iter->value().ToString(); }
  virtual bool valid() { return _iter->Valid(); }

private:
  leveldb::Iterator* _iter;
};

class LevelDBTransaction : public Transaction {
public:
  explicit LevelDBTransaction(leveldb::DB* db) : _db(db) { CHECK_NOTNULL(_db); }
  virtual void Put(const string& key, const string& value) {
    _batch.Put(key, value);
  }
  virtual void Commit() {
    leveldb::Status status = _db->Write(leveldb::WriteOptions(), &_batch);
    CHECK(status.ok()) << "Failed to write batch to leveldb "
                       << std::endl << status.ToString();
  }

private:
  leveldb::DB* _db;
  leveldb::WriteBatch _batch;

  DISABLE_COPY_AND_ASSIGN(LevelDBTransaction);
};

class LevelDB : public DB {
public:
  LevelDB() : _db(NULL) { }
  virtual ~LevelDB() { Close(); }
  virtual void Open(const string& source, Mode mode);
  virtual void Close() {
    if (_db != NULL) {
      delete _db;
      _db = NULL;
    }
  }
  virtual LevelDBCursor* NewCursor() {
    return new LevelDBCursor(_db->NewIterator(leveldb::ReadOptions()));
  }
  virtual LevelDBTransaction* NewTransaction() {
    return new LevelDBTransaction(_db);
  }

private:
  leveldb::DB* _db;
};

}  // namespace db
}  // namespace cream

#endif  // CREAM_UTIL_DB_LEVELDB_H
