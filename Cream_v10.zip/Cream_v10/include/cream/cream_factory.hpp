#ifndef CREAM_CREAM_FACTORY_H
#define CREAM_CREAM_FACTORY_H

#include <unordered_map>
#include <string>
#include <vector>

#include "glog/logging.h"

#include "cream/cream.h"
#include "cream/proto/cream.pb.h"

namespace cream {

using std::unordered_map;
using std::string;
using std::vector;

template <typename Dtype>
class Cream;

template <typename Dtype>
class CreamRegistry {
public:
  typedef Cream<Dtype>* (*Creator)(const SolverParameter&);
  typedef unordered_map<string, Creator> CreatorRegistry;

  static CreatorRegistry& Registry() {
    static CreatorRegistry* g_registry_ = new CreatorRegistry();
    return *g_registry_;
  }

  // Adds a creator.
  static void AddCreator(const string& type, Creator creator) {
    CreatorRegistry& registry = Registry();
    CHECK_EQ(registry.count(type), 0)
        << "Cream type " << type << " already registered.";
    registry[type] = creator;
  }

  // Get a Cream using a SolverParameter.
  static Cream<Dtype>* CreateCream(const SolverParameter& param) {
    const string& type = param.cream().type();
    CreatorRegistry& registry = Registry();
    CHECK_EQ(registry.count(type), 1) << "Unknown Cream type: " << type
        << " (known types: " << CreamTypeListString() << ")";
    return registry[type](param);
  }

  static vector<string> CreamTypeList() {
    CreatorRegistry& registry = Registry();
    vector<string> Cream_types;
    for (typename CreatorRegistry::iterator iter = registry.begin();
         iter != registry.end(); ++iter) {
      Cream_types.push_back(iter->first);
    }
    return Cream_types;
  }

private:
  // Cream registry should never be instantiated - everything is done with its
  // static variables.
  CreamRegistry() {}

  static string CreamTypeListString() {
    vector<string> Cream_types = CreamTypeList();
    string Cream_types_str;
    for (vector<string>::iterator iter = Cream_types.begin();
         iter != Cream_types.end(); ++iter) {
      if (iter != Cream_types.begin()) {
        Cream_types_str += ", ";
      }
      Cream_types_str += *iter;
    }
    return Cream_types_str;
  }
};


template <typename Dtype>
class CreamRegisterer {
public:
  CreamRegisterer(const string& type,
      Cream<Dtype>* (*creator)(const SolverParameter&)) {
    // LOG(INFO) << "Registering Cream type: " << type;
    CreamRegistry<Dtype>::AddCreator(type, creator);
  }
};


#define REGISTER_CREAM_CREATOR(type, creator)                                 \
  static CreamRegisterer<float> g_creator_f_##type(#type, creator<float>);    \
  static CreamRegisterer<double> g_creator_d_##type(#type, creator<double>)   \

#define REGISTER_CREAM_CLASS(type)                                            \
  template <typename Dtype>                                                    \
  Cream<Dtype>* Creator_##type(                                       \
      const SolverParameter& param)                                            \
  {                                                                            \
    return new type<Dtype>(param);                                     \
  }                                                                            \
  REGISTER_CREAM_CREATOR(type, Creator_##type)

}  // namespace cream

#endif  // CREAM_CREAM_FACTORY_H
