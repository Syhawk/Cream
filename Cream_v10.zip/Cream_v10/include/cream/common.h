#ifndef CREAM_COMMON_H
#define CREAM_COMMON_H

#include <gflags/gflags.h>
#include <glog/logging.h>
#include <string>
#include <vector>
#include <cmath>

#include "google/protobuf/message.h"
#include "cream/proto/cream.pb.h"

// Convert macro to string
#define STRINGIFY(m) #m
#define AS_STRING(m) STRINGIFY(m)

// gflags 2.1 issue: namespace google was changed to gflags without warning.
// Luckily we will be able to use GFLAGS_GFLAGS_H_ to detect if it is version
// 2.1. If yes, we will add a temporary solution to redirect the namespace.
// TODO(Yangqing): Once gflags solves the problem in a more elegant way, let's
// remove the following hack.
#ifndef GFLAGS_GFLAGS_H_
namespace gflags = google;
#endif  // GFLAGS_GFLAGS_H_

// Disable the copy and assignment operator for a class.
#define DISABLE_COPY_AND_ASSIGN(classname) \
private:\
  classname(const classname&);\
  classname& operator=(const classname&)

// Instantiate a class with float and double specifications.
#define INSTANTIATE_CLASS(classname) \
  char gInstantiationGuard##classname; \
  template class classname<float>; \
  template class classname<double>

// A simple macro to mark codes that are not implemented, so that when the code
// is executed we will see a fatal log.
#define NOT_IMPLEMENTED LOG(FATAL) << "Not Implemented Yet"


namespace cream {

using std::string;
using std::vector;
using ::google::protobuf::Message;


// A global initialization function that you should call in your main function.
// Currently it initializes google flags and google logging.
void GlobalInit(int* pargc, char*** pargv);

// Read parameters from a file into a SolverParameter proto message.
void ReadSolverParamsFromTextFileOrDie(const string& param_file,
                                       Message* param);

bool ReadProtoFromTextFile(const char* filename, Message* proto);

inline bool ReadProtoFromTextFile(const string& filename, Message* proto) {
  return ReadProtoFromTextFile(filename.c_str(), proto);
}

void ReadDatumsFromBinaryFile(const string& path,
								const string& type,
								vector<Datum>* datums);

void WriteDatumsIntoBinaryFile(const vector<Datum>& datums,
								const string& path,
    							const string& type);

template <typename Dtype>
Dtype Sigmoid(Dtype val);

template <typename Dtype>
Dtype EuclideanDistance(const vector<Dtype>& v1, const vector<Dtype>& v2);

template <typename Dtype>
Dtype ManhattanDistance(const vector<Dtype>& v1, const vector<Dtype>& v2);

template <typename Dtype>
Dtype CosineDistance(const vector<Dtype>& v1, const vector<Dtype>& v2);

template <typename Dtype>
Dtype MinkowskiDistance(const vector<Dtype>& v1, const vector<Dtype>& v2, Dtype lambda);

template <typename Dtype>
Dtype LinearDistance(const vector<Dtype>& v1, const vector<Dtype>& v2);

template <typename Dtype>
Dtype LogisticDistance(const vector<Dtype>& v1, const vector<Dtype>& v2);

template <typename Dtype>
Dtype Calculate_H_X(const vector<Dtype>& v1,
                    const vector<Dtype>& v2,
                    const string& type,
                    Dtype lambda = 0);

template <typename Dtype>
Dtype Calculate_H_X(const vector<Dtype>& v1,
                    const vector<Dtype>& v2,
                    SolverParameter::H_X_POLICY type,
                    Dtype lambda = 0);

template <typename Dtype>
Dtype EuclideanDistance(const vector<Dtype>& v1, const vector<Dtype>& v2) {
  CHECK_EQ(v1.size(), v2.size());
  CHECK_GT(v1.size(), 0);

  Dtype h_x = 0;
  for (size_t i = 0; i < v1.size(); ++i) {
    h_x += pow(v1[i] - v2[i], 2);
  }

  return sqrt(h_x);
}

template <typename Dtype>
Dtype ManhattanDistance(const vector<Dtype>& v1, const vector<Dtype>& v2) {
  CHECK_EQ(v1.size(), v2.size());
  CHECK_GT(v1.size(), 0);

  Dtype h_x = 0;
  for (size_t i = 0; i < v1.size(); ++i) {
    h_x += fabs(v1[i] - v2[i]);
  }

  return h_x;
}

template <typename Dtype>
Dtype Sigmoid(Dtype val) {
  return Dtype(1) / (Dtype(1) + exp(-val));
}

template <typename Dtype>
Dtype CosineDistance(const vector<Dtype>& v1, const vector<Dtype>& v2) {
  CHECK_EQ(v1.size(), v2.size());
  CHECK_GT(v1.size(), 0);

  Dtype abs_v1 = 0;
  for (size_t i = 0; i < v1.size(); ++i) {
    abs_v1 += v1[i] * v1[i];
  }

  Dtype abs_v2 = 0;
  for (size_t i = 0; i < v2.size(); ++i) {
    abs_v2 += v2[i] * v2[i];
  }

  Dtype cross = 0;
  for (size_t i = 0; i < v1.size(); ++i) {
    cross += v1[i] * v2[i];
  }

  return cross / (sqrt(abs_v1) * sqrt(abs_v2));
}

template <typename Dtype>
Dtype MinkowskiDistance(const vector<Dtype>& v1, const vector<Dtype>& v2, Dtype lambda) {
  CHECK_EQ(v1.size(), v2.size());
  CHECK_GT(v1.size(), 0);

  Dtype h_x = 0;
  for (size_t i = 0; i < v1.size(); ++i) {
    h_x += pow(fabs(v1[i] - v2[i]), lambda);
  }

  return pow(h_x, 1 / lambda);
}

template <typename Dtype>
Dtype LinearDistance(const vector<Dtype>& v1, const vector<Dtype>& v2) {
  CHECK_EQ(v1.size(), v2.size());
  CHECK_GT(v1.size(), 0);

  Dtype h_x = 0;
  for (size_t i = 0; i < v1.size(); ++i) {
    h_x += v1[i] * v2[i];
  }

  return h_x;
}

template <typename Dtype>
Dtype LogisticDistance(const vector<Dtype>& v1, const vector<Dtype>& v2) {
  return Sigmoid(LinearDistance(v1, v2));
}

template <typename Dtype>
Dtype Calculate_H_X(const vector<Dtype>& v1,
                    const vector<Dtype>& v2,
                    const string& type,
                    Dtype lambda = 0) {
  if (type == "Euclidean") {
    return EuclideanDistance(v1, v2);
  } else if (type == "Manhattan") {
    return ManhattanDistance(v1, v2);
  } else if (type == "Cosine") {
    return CosineDistance(v1, v2);
  } else if (type == "Minkowski") {
    return MinkowskiDistance(v1, v2, lambda);
  } else if (type == "Linear") {
    return LinearDistance(v1, v2);
  } else if (type == "Logistic") {
    return LogisticDistance(v1, v2);
  } else {
    LOG(ERROR) << type << " error.";
    exit(0);
  }

  return 0;
}

template <typename Dtype>
Dtype Calculate_H_X(const vector<Dtype>& v1,
                    const vector<Dtype>& v2,
                    SolverParameter::H_X_POLICY type,
                    Dtype lambda = 0) {
  switch (type) {
    case SolverParameter_H_X_POLICY_MINKOWSKI:
      return MinkowskiDistance(v1, v2, lambda);
    case SolverParameter_H_X_POLICY_EUCLIDEAN:
      return EuclideanDistance(v1, v2);
    case SolverParameter_H_X_POLICY_MANHATTAN:
      return ManhattanDistance(v1, v2);
    case SolverParameter_H_X_POLICY_COSINE:
      return CosineDistance(v1, v2);
    case SolverParameter_H_X_POLICY_LINEAR:
      return LinearDistance(v1, v2);
    case SolverParameter_H_X_POLICY_LOGISTIC:
      return LogisticDistance(v1, v2);
    default:
      LOG(ERROR) << type << " error.";
      exit(0);
  }

  return 0;
}

}  // namespace cream

#endif  // CREAM_COMMON_H
