#include <string>
#include <vector>

#include "cream/algorithm/hashcode.h"
#include "cream/proto/cream.pb.h"

namespace cream {

using std::string;
using std::vector;
using boost::shared_ptr;


template <typename Dtype>
void Hashcode<Dtype>::init() {
  this->_candy = shared_ptr<HashcodeCandy<Dtype>>(new HashcodeCandy<Dtype>());
  this->_candy->init(this->_param);

  ReadSolverParamsFromTextFileOrDie(this->_param.cream().path(), &_hashcode_param);
}

template <typename Dtype>
void Hashcode<Dtype>::train() {
  LOG(INFO) << "Train Hashcode model...";
  calculate_hashcode();
  snapshot();
}

template <typename Dtype>
void Hashcode<Dtype>::calculate_hashcode() {
  CHECK(this->_param.has_train_file());
  CHECK(this->_candy->weight().empty());
  generate_hashcode_by_mean_value();
  generate_hashcode_by_feature_value();
  this->_candy->add_unique_label(type());
}

template <typename Dtype>
void Hashcode<Dtype>::generate_hashcode_by_mean_value() {
  if (!_hashcode_param.has_mean_value()) {
    return;
  }

  this->_candy->mutable_weight()->push_back(shared_ptr<vector<Dtype>>(new vector<Dtype>()));
  size_t size = this->_candy->shape().width * this->_candy->shape().height
      * this->_candy->shape().channel;
  for (size_t i = 0; i < size; ++i)
  this->_candy->mutable_weight()->back()->push_back(Dtype(_hashcode_param.mean_value()));
}

template <typename Dtype>
void Hashcode<Dtype>::generate_hashcode_by_feature_value() {
  if (_hashcode_param.has_mean_value() && _hashcode_param.mean_value() > 1e-6) {
    return;
  }

  this->_candy->mutable_weight()->push_back(shared_ptr<vector<Dtype>>(new vector<Dtype>()));
  size_t size = this->_candy->shape().width * this->_candy->shape().height
      * this->_candy->shape().channel;
  for (size_t i = 0; i < this->_candy->data_size(); ++i) {
    CHECK_EQ(size, this->_candy->data(i).size());
    for (size_t j = 0; j < size; ++j) {
      if (this->_candy->mutable_weight()->back()->size() < size) {
        this->_candy->mutable_weight()->back()->push_back(this->_candy->data(i)[j]);
      } else {
        this->_candy->mutable_weight()->back()->at(j) += this->_candy->data(i)[j];
      }
    }
  }

  for (size_t i = 0; i < size; ++i) {
    this->_candy->mutable_weight(0)->at(i) /= this->_candy->shape().num;
  }
}

template <typename Dtype>
void Hashcode<Dtype>::test() {
  LOG(INFO) << "TODO: for future.";
}

INSTANTIATE_CLASS(Hashcode);
REGISTER_CREAM_CLASS(Hashcode);

}  // namespace cream
