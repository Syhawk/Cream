#include <string>
#include <vector>

#include "cream/algorithm/logistic.h"
#include "cream/proto/cream.pb.h"

namespace cream {

using std::string;
using std::vector;
using boost::shared_ptr;


template <typename Dtype>
void Logistic<Dtype>::init() {
  this->_candy = shared_ptr<LogisticCandy<Dtype>>(new LogisticCandy<Dtype>());
  this->_candy->init(this->_param);

  ReadSolverParamsFromTextFileOrDie(this->_param.cream().path(), &_logistic_param);
}

template <typename Dtype>
void Logistic<Dtype>::train_one_epoch() {
  this->_in_accuracy = 0;
  this->_loss = Dtype(0);
  for (size_t i = 0; i < this->_candy->label_size(); ++i) {
    vector<pair<Dtype, string>> top_n;
    for (size_t j = 0; j < this->_candy->unique_label_size(); ++j) {
      Cream<Dtype>::h_x(i, j);
      update_weight(i, j);
      maintain_top_n(this->_candy->unique_label(j), &top_n);
    }
    loss(this->_candy->label(i), top_n);
    maintain_acc(top_n, this->_candy->label(i), &this->_in_accuracy);
  }
}

template <typename Dtype>
void Logistic<Dtype>::loss(const string& label, const vector<pair<Dtype, string>>& top_n) {
  CHECK(!top_n.empty());
  if (label != top_n[0].second) {
    this->_loss += Dtype(1) * this->_candy->unique_label_size();
  } else {
    this->_loss += top_n[0].first * this->_candy->unique_label_size();
  }
}

template <typename Dtype>
Dtype Logistic<Dtype>::regularization(Dtype val) {
  if (_logistic_param.regularization() == LogisticParameter_REGULARIZATION_L1) {
    if (val > 0) {
      return Dtype(1);
    } else {
      return Dtype(0);
    }
  } else if (_logistic_param.regularization() == LogisticParameter_REGULARIZATION_L2) {
    return fabs(val);
  } else {
    return Dtype(0);
  }
}

template <typename Dtype>
void Logistic<Dtype>::update_weight(size_t idx_x, size_t idx_w) {
  CHECK_GT(this->_candy->data_size(), idx_x);
  CHECK_GT(this->_candy->weight_size(), idx_w);
  CHECK_EQ(this->_candy->data(idx_x).size(), this->_candy->weight(idx_w).size());
  CHECK_EQ(this->_candy->data_size(), this->_candy->label_size());
  CHECK_EQ(this->_candy->weight_size(), this->_candy->unique_label_size());

  Dtype accuracy = Dtype(1);
  if (_logistic_param.update_policy() == LogisticParameter_UPDATE_POLICY_USE_LABEL) {
    if (this->_candy->label(idx_x) != this->_candy->unique_label(idx_w)) {
      accuracy = Dtype(0);
    }
  }

  for (size_t i = 0; i < this->_candy->weight(idx_w).size(); ++i) {
    this->_candy->mutable_weight(idx_w)->at(i) =
        this->_rate * (accuracy - this->_h_x) * this->_candy->data(idx_x)[i]
        + this->_param.lr().momentum() * this->_candy->weight(idx_w)[i]
        + _logistic_param.lambda() * regularization(this->_candy->weight(idx_w)[i]);
  }
}

INSTANTIATE_CLASS(Logistic);
REGISTER_CREAM_CLASS(Logistic);

}  // namespace cream
