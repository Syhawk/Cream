#include <unordered_map>

#include "cream/algorithm/logistic_candy.h"

namespace cream {

using std::unordered_map;


template <typename Dtype>
void LogisticCandy<Dtype>::init_other_param() {
  for (size_t i = 0; i < data_size(); ++i) {
    mutable_data(i)->push_back(Dtype(1));
  }

  for (size_t i = 0; i < test_data_size(); ++i) {
    mutable_test_data(i)->push_back(Dtype(1));
  }

  if (unique_label_size() == 0) {
    CHECK_EQ(label_size(), data_size());
    vector<int> cnt(label_size(), 0);
    unordered_map<string, size_t> label_set;
    for (size_t i = 0; i < label_size(); ++i) {
      if (label_set.find(label(i)) == label_set.end()) {
        label_set[label(i)] = unique_label_size();
        add_unique_label(label(i));
        add_weight(vector<Dtype>());
      }

      int index = label_set[label(i)];
      cnt[index] += 1;
      for (size_t j = 0; j < data(i).size(); ++j) {
        if (weight(index).size() < data(i).size()) {
          mutable_weight(index)->push_back(data(i)[j]);
        } else {
          mutable_weight(index)->at(j) += data(i)[j];
        }
      }
    }

  	for (size_t i = 0; i < weight_size(); ++i) {
      for (size_t j = 0; j < weight(i).size(); ++j) {
        mutable_weight(i)->at(j) /= cnt[i];
      }
    }
  }
}

INSTANTIATE_CLASS(LogisticCandy);

}  // namespace cream
