#include "cream/algorithm/hashcode_candy.h"

namespace cream {

INSTANTIATE_CLASS(HashcodeCandy);

}  // namespace cream
