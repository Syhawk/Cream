#include <string>
#include <vector>

#include "cream/common.h"
#include "cream/algorithm/k_means.h"
#include "cream/proto/cream.pb.h"

namespace cream {

using std::string;
using std::vector;
using boost::shared_ptr;


template <typename Dtype>
void KMeans<Dtype>::init() {
  this->_candy = shared_ptr<KMeansCandy<Dtype>>(new KMeansCandy<Dtype>());
  this->_candy->init(this->_param);

  ReadSolverParamsFromTextFileOrDie(this->_param.cream().path(), &_k_means_param);
}

template <typename Dtype>
void KMeans<Dtype>::train_one_epoch() {
  this->_in_accuracy = 0;
  this->_loss = 0;
  for (size_t i = 0; i < this->_candy->label_size(); ++i) {
    vector<pair<Dtype, string>> top_n;
    for (size_t j = 0; j < this->_candy->unique_label_size(); ++j) {
      Cream<Dtype>::h_x(i, j);
      loss(i, j);
      Cream<Dtype>::maintain_top_n(this->_candy->unique_label(j), &top_n);
    }
    Cream<Dtype>::maintain_acc(top_n, this->_candy->label(i), &(this->_in_accuracy));

    get_index_to_label(top_n, i);
  }

  update_weight();
}

template <typename Dtype>
void KMeans<Dtype>::get_index_to_label(const vector<pair<Dtype, string>>& top_n,
                                        int label_index) {
  CHECK(!top_n.empty());
  string key = top_n[0].second;
  if (_k_means_param.update_policy() == KMeansParameter_UPDATE_POLICY_USE_LABEL) {
    if (key == this->_candy->label(label_index)) {
      return;
    }
    key = this->_candy->label(label_index);
  }

  size_t index = this->_candy->label_to_index(key);
  this->_candy->mutable_index_to_data()->at(index)->push_back(label_index);
}

template <typename Dtype>
void KMeans<Dtype>::loss(size_t idx_x, size_t idx_p) {
  CHECK_EQ(this->_candy->data_size(), this->_candy->label_size());
  CHECK_EQ(this->_candy->weight_size(), this->_candy->unique_label_size());

  if (this->_candy->label(idx_x) == this->_candy->unique_label(idx_p)) {
    this->_loss += this->_h_x;
  }
}

template <typename Dtype>
void KMeans<Dtype>::update_weight() {
  CHECK_EQ(this->_candy->index_to_data_size(), this->_candy->weight_size());

  if (this->_param.update_weight() == false) {
    return;
  }

  for (size_t i = 0; i < this->_candy->index_to_data_size(); ++i) {
    vector<Dtype> tmp;
    for (size_t j = 0; j < this->_candy->index_to_data(i).size(); ++j) {
      size_t index = this->_candy->index_to_data(i)[j];
      CHECK_GT(this->_candy->data_size(), index);
      for (size_t k = 0; k < this->_candy->data(index).size(); ++k) {
        if (tmp.size() == 0) {
          tmp = vector<Dtype>(this->_candy->data(index).size(), Dtype(0));
        }
        tmp[k] += this->_candy->data(index)[k];
      }
    }

    size_t size = this->_candy->index_to_data(i).size();
    for (size_t j = 0; j < tmp.size(); ++j) {
      this->_candy->mutable_weight()->at(i)->at(j) = tmp[j] / size;
    }
  }

  for (size_t i = 0; i < this->_candy->index_to_data_size(); ++i) {
    this->_candy->mutable_index_to_data()->at(i)->clear();
  }
}

INSTANTIATE_CLASS(KMeans);
REGISTER_CREAM_CLASS(KMeans);

}  // namespace cream
