#include <vector>
#include <string>
#include <unordered_map>

#include "cream/algorithm/k_means_candy.h"

namespace cream {

using std::string;
using std::vector;
using std::make_pair;
using std::unordered_map;


template <typename Dtype>
void KMeansCandy<Dtype>::init_other_param() {
  init_index_to_data();
  init_label_to_index();

  if (unique_label_size() == 0) {
    vector<int> cnt(label_size(), 0);
    CHECK_EQ(label_size(), data_size());

    for (size_t i = 0; i < label_size(); ++i) {
      if (label_to_index().find(label(i)) == label_to_index().end()) {
        mutable_label_to_index()->insert(make_pair(label(i), unique_label_size()));
        add_unique_label(label(i));
        add_weight(vector<Dtype>());
        add_index_to_data(vector<size_t>());
      }

      int index = label_to_index(label(i));
      cnt[index] += 1;
      for (size_t j = 0; j < data(i).size(); ++j) {
        if (weight(index).size() < data(i).size()) {
          mutable_weight(index)->push_back(data(i)[j]);
        } else {
          mutable_weight(index)->at(j) += data(i)[j];
        }
      }
    }

  	for (size_t i = 0; i < weight_size(); ++i) {
      for (size_t j = 0; j < weight(i).size(); ++j) {
        mutable_weight(i)->at(j) /= cnt[i];
      }
    }
  }
}

INSTANTIATE_CLASS(KMeansCandy);

}  // namespace cream
