#include <vector>
#include <string>
#include <ctime>
#include <unordered_set>
#include <boost/scoped_ptr.hpp>

#include "cream/util/db.h"
#include "cream/candy.h"

namespace cream {

using std::unordered_set;
using boost::scoped_ptr;

template <typename Dtype>
void Candy<Dtype>::init(const SolverParameter& param) {
  srand(unsigned(time(0)));

  init_train(param);
  init_test(param);
  init_weight(param);
  init_other_param();
}

template <typename Dtype>
void Candy<Dtype>::init_train(const SolverParameter& param) {
  if (!param.has_train_file()) {
    return;
  }

  vector<Datum> datums;
  ReadDatumsFromBinaryFile(param.train_file().path(), param.train_file().type(), &datums);
  CHECK(!datums.empty()) << "Datums should not be null.";

  _shape.width = datums[0].width();
  _shape.height = datums[0].height();
  _shape.channel = datums[0].channels();
  _shape.num = datums.size();

  _data = Vecs(new vector<shared_ptr<vector<Dtype>>>());
  _data->resize(_shape.num);
  _label = Strs(new vector<shared_ptr<string>>());
  _label->resize(_shape.num);
  _path = Strs(new vector<shared_ptr<string>>());
  _path->resize(_shape.num);
  _unique_label = Strs(new vector<shared_ptr<string>>());

  unordered_set<string> unique_label;
  long size = _shape.width * _shape.height * _shape.channel;
  for (size_t i = 0; i < datums.size(); ++i) {
    CHECK_EQ(_shape.width, datums[i].width());
    CHECK_EQ(_shape.height, datums[i].height());
    CHECK_EQ(_shape.channel, datums[i].channels());
    CHECK_EQ(size, datums[i].float_data_size());

    shared_ptr<vector<Dtype>> feature(new vector<Dtype>());
    feature->resize(size);

    for (size_t j = 0; j < datums[i].float_data_size(); ++j) {
      (*feature)[j] = datums[i].float_data(j);
    }

    (*_data)[i] = feature;
    (*_label)[i] = shared_ptr<string>(new string(datums[i].img_label()));
    (*_path)[i] = shared_ptr<string>(new string(datums[i].name()));

    if (unique_label.find(datums[i].img_label()) == unique_label.end()) {
      unique_label.insert(datums[i].img_label());
      _unique_label->push_back(shared_ptr<string>(new string(datums[i].img_label())));
    }
  }
}

template <typename Dtype>
void Candy<Dtype>::init_test(const SolverParameter& param) {
  if (!param.has_test_file()) {
    return;
  }

  vector<Datum> datums;
  ReadDatumsFromBinaryFile(param.test_file().path(), param.test_file().type(), &datums);
  CHECK(!datums.empty()) << "Datums should not be null.";

  _test_shape.width = datums[0].width();
  _test_shape.height = datums[0].height();
  _test_shape.channel = datums[0].channels();
  _test_shape.num = datums.size();

  _test_data = Vecs(new vector<shared_ptr<vector<Dtype>>>());
  _test_data->resize(_test_shape.num);
  _test_label = Strs(new vector<shared_ptr<string>>());
  _test_label->resize(_test_shape.num);
  _test_path = Strs(new vector<shared_ptr<string>>());
  _test_path->resize(_test_shape.num);

  long size = _test_shape.width * _test_shape.height * _test_shape.channel;
  for (size_t i = 0; i < datums.size(); ++i) {
    CHECK_EQ(_test_shape.width, datums[i].width());
    CHECK_EQ(_test_shape.height, datums[i].height());
    CHECK_EQ(_test_shape.channel, datums[i].channels());
    CHECK_EQ(size, datums[i].float_data_size());

    shared_ptr<vector<Dtype>> feature(new vector<Dtype>());
    feature->resize(size);

    for (size_t j = 0; j < datums[i].float_data_size(); ++j) {
      (*feature)[j] = datums[i].float_data(j);
    }

    (*_test_data)[i] = feature;
    (*_test_label)[i] = shared_ptr<string>(new string(datums[i].img_label()));
    (*_test_path)[i] = shared_ptr<string>(new string(datums[i].name()));
  }
}

template <typename Dtype>
void Candy<Dtype>::init_weight(const SolverParameter& param) {
  _weight = Vecs(new vector<shared_ptr<vector<Dtype>>>());
  _unique_label = Strs(new vector<shared_ptr<string>>());

  if (!param.has_input_model_file()) {
    return;
  }

  vector<Datum> datums;
  ReadDatumsFromBinaryFile(param.input_model_file().path(),
      param.input_model_file().type(), &datums);
  CHECK(!datums.empty()) << "Datums should not be null.";
  _weight->resize(datums.size());
  _unique_label->resize(datums.size());

  size_t size = datums[0].float_data_size();
  for (size_t i = 0; i < datums.size(); ++i) {
    CHECK_EQ(size, datums[i].float_data_size());

    shared_ptr<vector<Dtype>> feature(new vector<Dtype>());
    feature->resize(size);

    for (size_t j = 0; j < datums[i].float_data_size(); ++j) {
      (*feature)[j] = datums[i].float_data(j);
    }

    (*_weight)[i] = feature;
    (*_unique_label)[i] = shared_ptr<string>(new string(datums[i].img_label()));
  }
}

template <typename Dtype>
void Candy<Dtype>::shuffle() {
  CHECK_EQ(shape().num, data_size());
  CHECK_EQ(shape().num, label_size());
  CHECK_EQ(shape().num, path_size());

  for (size_t i = 0; i < shape().num; ++i) {
    size_t rd = rand() % shape().num;
    swap_data(i, rd);
    swap_label(i, rd);
    swap_path(i, rd);
  }
}

INSTANTIATE_CLASS(Candy);

}  // namespace cream
