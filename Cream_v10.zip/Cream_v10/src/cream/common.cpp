#include <string>
#include <vector>
#include <fcntl.h>
#include <google/protobuf/io/coded_stream.h>
#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <google/protobuf/text_format.h>
#include <boost/shared_ptr.hpp>
#include <boost/scoped_ptr.hpp>

#include "cream/common.h"
#include "cream/util/db.h"
#include "cream/proto/cream.pb.h"

namespace cream {

using std::string;
using std::vector;
using std::to_string;
using boost::shared_ptr;
using boost::scoped_ptr;
using google::protobuf::io::FileInputStream;
using google::protobuf::io::FileOutputStream;

void GlobalInit(int* pargc, char*** pargv) {
  // Google flags.
  ::gflags::ParseCommandLineFlags(pargc, pargv, true);
  // Google logging.
  ::google::InitGoogleLogging(*(pargv)[0]);
  // Provide a backtrace on segfault.
  ::google::InstallFailureSignalHandler();
}

// Read parameters from a file into a Message proto message.
void ReadSolverParamsFromTextFileOrDie(const string& param_file,
                                       Message* param) {
  CHECK(ReadProtoFromTextFile(param_file, param))
      << "Failed to parse SolverParameter file: " << param_file;
}

bool ReadProtoFromTextFile(const char* filename, Message* proto) {
  int fd = open(filename, O_RDONLY);
  CHECK_NE(fd, -1) << "File not found: " << filename;
  FileInputStream* input = new FileInputStream(fd);
  bool success = google::protobuf::TextFormat::Parse(input, proto);
  delete input;
  close(fd);
  return success;
}

void ReadDatumsFromBinaryFile(const string& path,
                              const string& type,
                              vector<Datum>* datums) {
  shared_ptr<db::DB> db(db::GetDB(type));
  db->Open(path, db::READ);
  scoped_ptr<db::Cursor> cursor(db->NewCursor());

  while (cursor->valid()) {
    Datum datum;
    CHECK(datum.ParseFromString(cursor->value()));
    datums->push_back(datum);
    cursor->Next();
  }
}

void WriteDatumsIntoBinaryFile(const vector<Datum>& datums,
                              const string& path,
                              const string& type) {
  if (access(path.c_str(), F_OK) == 0) {
    LOG(WARNING) << path << " exists, and it will be overwrited.";
    system(("rm -rf " + path).c_str());
  }

  shared_ptr<db::DB> db(db::GetDB(type));
  db->Open(path, db::NEW);
  shared_ptr<db::Transaction> txn(db->NewTransaction());
  for (size_t i = 0; i < datums.size(); ++i) {
    string out;
    CHECK(datums[i].SerializeToString(&out));
    txn->Put(to_string(i), out);
    if (i % 1000 == 0 || i + 1 == datums.size()) {
      txn->Commit();
      txn.reset(db->NewTransaction());
    }
  }
  db->Close();
}

}  // namespace cream
