#include <string>

#include "cream/util/db.h"
#include "cream/util/db_leveldb.h"
#include "cream/util/db_lmdb.h"

namespace cream { namespace db {

DB* GetDB(SolverParameter::DB backend) {
  switch (backend) {
    case SolverParameter_DB_LEVELDB:
      return new LevelDB();
    case SolverParameter_DB_LMDB:
      return new LMDB();
    default:
      LOG(FATAL) << "Unknown database backend";
      return NULL;
  }
}

DB* GetDB(const string& backend) {
  if (backend == "leveldb") {
    return new LevelDB();
  }
  if (backend == "lmdb") {
    return new LMDB();
  }
  LOG(FATAL) << "Unknown database backend";
  return NULL;
}

}  // namespace db
}  // namespace cream
