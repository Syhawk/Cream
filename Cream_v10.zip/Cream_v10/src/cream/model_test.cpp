#include <string>
#include <vector>
#include <utility>
#include <glog/logging.h>
#include <boost/scoped_ptr.hpp>

#include "cream/proto/cream.pb.h"
#include "cream/model_test.h"
#include "cream/common.h"

namespace cream {

using std::vector;
using std::string;
using std::pair;
using std::make_pair;
using boost::scoped_ptr;


void ModelTest::init() {
  accuracy.clear();
  for (int i = 1; i <= 50; ++i) {
    accuracy.push_back(make_pair(i, 0));
  }
/*
  accuracy.push_back(make_pair(1, 0));
  accuracy.push_back(make_pair(3, 0));
  accuracy.push_back(make_pair(5, 0));
  accuracy.push_back(make_pair(10, 0));
  accuracy.push_back(make_pair(15, 0));
  accuracy.push_back(make_pair(20, 0));
  accuracy.push_back(make_pair(25, 0));
  accuracy.push_back(make_pair(30, 0));
  accuracy.push_back(make_pair(40, 0));
  accuracy.push_back(make_pair(50, 0));
*/
  datums.clear();
}

void ModelTest::read_model(const string& path, const string& type) {
  vector<Datum> datums;
  ReadDatumsFromBinaryFile(path, type, &datums);
  weights.clear();

  for (size_t i = 0; i < datums.size(); ++i) {
    Point p;
    p.label = datums[i].img_label();
    for (size_t j = 0; j < datums[i].float_data_size(); ++j) {
      p.weight.push_back(datums[i].float_data(j));
    }
    weights.push_back(p);
  }
}

void ModelTest::read_feature(const string& path,
                            const string& type,
                            const string& filter,
                            const string& mode,
                            float lambda,
                            const string& sort_mode) {
  vector<Datum> datums;
  ReadDatumsFromBinaryFile(path, type, &datums);

  for (size_t i = 0; i < weights.size(); ++i) {
    weights[i].features.clear();
    weights[i].labels.clear();
    weights[i].paths.clear();
  }

  for (size_t i = 0; i < datums.size(); ++i) {
    if (datums[i].name().find(filter) != string::npos) {
      continue;
    }

    vector<float> feature;
    for (size_t j = 0; j < datums[i].float_data_size(); ++j) {
      feature.push_back(datums[i].float_data(j));
    }

    int index = -1;
    if (mode == "UseLabel") {
      for (size_t j = 0; j < weights.size(); ++j) {
        if (weights[j].label == datums[i].img_label()) {
          index = j;
          break;
        }
      }
    } else {
      float h_x = 0;
      for (size_t j = 0; j < weights.size(); ++j) {
        float tmp = Calculate_H_X(weights[j].weight, feature, mode, lambda);
        if (index == -1 || (sort_mode == "ASC" && h_x > tmp)
            || (sort_mode == "DESC" && h_x < tmp)) {
          h_x = tmp;
          index = j;
        }
      }
    }

    CHECK_GT(index, -1);
    weights[index].features.push_back(feature);
    weights[index].labels.push_back(datums[i].img_label());
    weights[index].paths.push_back(datums[i].name());
  }
}

void ModelTest::read_test_feature(const string& path, const string& type) {
  vector<Datum> datums;
  ReadDatumsFromBinaryFile(path, type, &datums);

  test_data = Point();
  for (size_t i = 0; i < datums.size(); ++i) {
    test_data.labels.push_back(datums[i].img_label());
    test_data.paths.push_back(datums[i].name());

    vector<float> feature;
    for (size_t j = 0; j < datums[i].float_data_size(); ++j) {
      feature.push_back(datums[i].float_data(j));
    }

    test_data.features.push_back(feature);
  }
}

void ModelTest::test(int top_n,
                    const string& space_mode,
                    float space_lambda,
                    const string& space_sort_mode,
                    const string& top_n_mode,
                    float top_n_lambda,
                    const string& top_n_sort_mode) {
  CHECK_EQ(test_data.features.size(), test_data.labels.size());
  CHECK_EQ(test_data.features.size(), test_data.paths.size());

  LOG(INFO) << "Starting testing...";

  int count = 0;
  for (size_t i = 0; i < test_data.features.size(); ++i) {
    // Generate space.
    generate_space(test_data.features[i], top_n, space_mode, space_lambda, space_sort_mode);
    // Generate top n.
    generate_top_n(test_data.features[i], top_n, top_n_mode, top_n_lambda, top_n_sort_mode);
    // Update Accuracy.
    update_accuracy_and_datums(test_data.labels[i], test_data.paths[i]);
    // Show accuracy.
    show_accuracy(++count, true);
  }
  show_accuracy(count, false);

  LOG(INFO) << "done.";
}

void ModelTest::generate_space(const vector<float>& feature,
                              int top_k,
                              const string& space_mode,
                              float space_lambda,
                              const string& space_sort_mode) {
  // Get retrieval top_n spaces.
  spaces.clear();
  if (space_sort_mode == "ASC") {
    for (size_t i = 0; i < weights.size(); ++i) {
      float h_x = Calculate_H_X(feature, weights[i].weight, space_mode, space_lambda);
      if (spaces.size() < top_k) {
        spaces.push_back(make_pair(h_x, i));
      } else if (spaces.back().first > h_x) {
        spaces.back() = make_pair(h_x, i);
      } else {
        continue;
      }
      for (int len = spaces.size() - 1;
          len > 0 && spaces[len - 1].first > spaces[len].first; --len) {
        swap(spaces[len - 1], spaces[len]);
      }
    }
  } else if (space_sort_mode == "DESC") {
    for (size_t i = 0; i < weights.size(); ++i) {
      float h_x = Calculate_H_X(feature, weights[i].weight, space_mode, space_lambda);
      if (spaces.size() < top_k) {
        spaces.push_back(make_pair(h_x, i));
      } else if (spaces.back().first < h_x) {
        spaces.back() = make_pair(h_x, i);
      } else {
        continue;
      }
      for (int len = spaces.size() - 1;
          len > 0 && spaces[len - 1].first < spaces[len].first; --len) {
        swap(spaces[len - 1], spaces[len]);
      }
    }
  } else {
    LOG(ERROR) << "space_sort_mode:" << space_sort_mode << " error!";
  }
}

void ModelTest::generate_top_n(const vector<float>& feature,
                              int top_k,
                              const string& top_n_mode,
                              float top_n_lambda,
                              const string& top_n_sort_mode) {
  // Get top_n similar imgs.
  top_n.clear();
  if (top_n_sort_mode == "ASC") {
    for (size_t i = 0; i < spaces.size(); ++i) {
      size_t index = spaces[i].second;
      for (size_t j = 0; j < weights[index].features.size(); ++j) {
        float h_x = Calculate_H_X(feature, weights[index].features[j], top_n_mode, top_n_lambda);
        if (top_n.size() < top_k) {
          top_n.push_back(make_pair(h_x,
              make_pair(weights[index].labels[j], weights[index].paths[j])));
        } else if (top_n.back().first > h_x) {
          top_n.back() = make_pair(h_x,
              make_pair(weights[index].labels[j], weights[index].paths[j]));
        } else {
          continue;
        }
        for (int len = top_n.size() - 1;
            len > 0 && top_n[len - 1].first > top_n[len].first; --len) {
          swap(top_n[len - 1], top_n[len]);
        }
      }
    }
  } else if (top_n_sort_mode == "DESC") {
    for (size_t i = 0; i < spaces.size(); ++i) {
      size_t index = spaces[i].second;
      for (size_t j = 0; j < weights[index].features.size(); ++j) {
        float h_x = Calculate_H_X(feature, weights[index].features[j], top_n_mode, top_n_lambda);
        if (top_n.size() < top_k) {
          top_n.push_back(make_pair(h_x,
              make_pair(weights[index].labels[j], weights[index].paths[j])));
        } else if (top_n.back().first < h_x) {
          top_n.back() = make_pair(h_x,
              make_pair(weights[index].labels[j], weights[index].paths[j]));
        } else {
          continue;
        }
        for (int len = top_n.size() - 1;
            len > 0 && top_n[len - 1].first < top_n[len].first; --len) {
          swap(top_n[len - 1], top_n[len]);
        }
      }
    }
  } else {
    LOG(ERROR) << "top_n_mode:" << top_n_mode << " error!";
  }
}

void ModelTest::update_accuracy_and_datums(const string& label, const string& path) {
  Datum datum;
  datum.set_img_label(label);
  datum.set_name(path);

  // Update accuracy and datums.
  bool is_recorded = false;
  for (size_t i = 0; i < top_n.size(); ++i) {
    if (is_recorded == false && top_n[i].second.first == label) {
      for (int j = accuracy.size() - 1; j >= 0 && accuracy[j].first > i; --j) {
        accuracy[j].second += 1;
      }
      is_recorded = true;
    }
    datum.add_imgs()->set_name(top_n[i].second.second);
  }

  datums.push_back(datum);
}

void ModelTest::show_accuracy(int count, bool is_showed) {
  if (count % 500 != 0 && is_showed) {
    return;
  }
  if (count % 500 == 0 && !is_showed) {
    return;
  }

  LOG(INFO) << "Test imgs num: " << count;
  for (size_t i = 0; i < accuracy.size(); ++i) {
    LOG(INFO) << "    Accuracy top " << accuracy[i].first << ": "
        << accuracy[i].second * 1.0 / count;
  }
}

void ModelTest::write_datums(const string& path, const string& type) {
  if (path.empty()) {
    return;
  }
  WriteDatumsIntoBinaryFile(datums, path, type);
}

} // cream
