#include <string>
#include <vector>
#include <unordered_map>

#include "cream/proto/cream.pb.h"
#include "cream/common.h"
#include "cream/similarity/hashcode_model_test.h"

namespace cream {

using std::vector;
using std::string;
using std::unordered_map;


string HashcodeModelTest::generate_hashcode(const vector<float>& feature,
																						const vector<float>& weight) {
	CHECK_EQ(feature.size(), weight.size());

	string hashcode = "";
	for (size_t i = 0; i < feature.size(); ++i) {
		if (feature[i] >= weight[i]) {
			hashcode += '1';
		} else {
			hashcode += '0';
		}
	}

	return hashcode;
}

void HashcodeModelTest::read_feature(const string& path,
								                    const string& type,
                                    const string& filter,
								                    const string& mode,
								                    float lambda,
								                    const string& sort_mode) {
	CHECK_EQ(this->weights.size(), 1);

	vector<float> weight = this->weights[0].weight;
	vector<Datum> datums;
  ReadDatumsFromBinaryFile(path, type, &datums);
  // Storage all feature by hashcode.
  unordered_map<string, Point> collection;

  for (size_t i = 0; i < datums.size(); ++i) {
    if (datums[i].name().find(filter) != string::npos) {
      continue;
    }

    vector<float> feature;
    for (size_t j = 0; j < datums[i].float_data_size(); ++j) {
      feature.push_back(datums[i].float_data(j));
    }

    string hashcode = generate_hashcode(feature, weight);
    if (collection.find(hashcode) == collection.end()) {
    	Point p;
    	for (size_t i = 0; i < hashcode.size(); ++i) {
    		p.weight.push_back(hashcode[i] == '1');
    	}
    	collection[hashcode] = p;
    }

    collection[hashcode].features.push_back(feature);
    collection[hashcode].labels.push_back(datums[i].img_label());
    collection[hashcode].paths.push_back(datums[i].name());
  }

  this->weights.clear();
  for (unordered_map<string, Point>::iterator itr = collection.begin();
  		itr != collection.end(); ++itr) {
  	this->weights.push_back(itr->second);
  }
}

} // namespace cream
