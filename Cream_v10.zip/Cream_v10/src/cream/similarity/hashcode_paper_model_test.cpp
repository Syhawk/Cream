#include <string>
#include <vector>
#include <glog/logging.h>

#include "cream/proto/cream.pb.h"
#include "cream/common.h"
#include "cream/similarity/hashcode_paper_model_test.h"

namespace cream {

using std::vector;
using std::string;

void HashcodePaperModelTest::read_feature(const string& path,
                                    const string& type,
                                    const string& filter,
                                    const string& mode,
                                    float lambda,
                                    const string& sort_mode) {
	CHECK_EQ(weights.size(), 1);

	vector<float> weight = this->weights[0].weight;
	vector<Datum> datums;
  ReadDatumsFromBinaryFile(path, type, &datums);
  this->weights.clear();

  for (size_t i = 0; i < datums.size(); ++i) {
    if (datums[i].name().find(filter) != string::npos) {
      continue;
    }
    this->weights.push_back(Point());
    vector<float> feature;
    for (size_t j = 0; j < datums[i].float_data_size(); ++j) {
      feature.push_back(datums[i].float_data(j));
    }

    string hashcode = generate_hashcode(feature, weight);
  	for (size_t i = 0; i < hashcode.size(); ++i) {
  		this->weights.back().weight.push_back(hashcode[i] == '1');
  	}

    this->weights.back().features.push_back(feature);
    this->weights.back().labels.push_back(datums[i].img_label());
    this->weights.back().paths.push_back(datums[i].name());
  }
}

} // namespace cream
