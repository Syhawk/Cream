#include <string>
#include <vector>
#include <unordered_map>

#include "cream/cream.h"
#include "cream/common.h"

namespace cream {

using std::string;
using std::vector;
using std::unordered_map;
using std::make_pair;
using std::to_string;


template <typename Dtype>
void Cream<Dtype>::generate_file_path() {
  _file_path = _param.output_model_file().path() + "_" + type() + "_epoch_" + to_string(_epoch)
      + "_" + _param.output_model_file().type() + ".creammodel";
}

template <typename Dtype>
void Cream<Dtype>::generate_datums() {
  CHECK_EQ(_candy->weight_size(), _candy->unique_label_size());
  
  _datums.clear();
  for (size_t i = 0; i < _candy->unique_label_size(); ++i) {
    Datum datum;
    datum.set_height(_candy->shape().height);
    datum.set_width(_candy->shape().width);
    datum.set_channels(_candy->shape().channel);
    datum.set_img_label(_candy->unique_label(i));
    for (size_t j = 0; j < _candy->weight(i).size(); ++j) {
      datum.add_float_data(_candy->weight(i)[j]);
    }
    
    _datums.push_back(datum);
  }
}

template <typename Dtype>
void Cream<Dtype>::snapshot() {
  if ((_param.snapshot_epoch() <= 0 || _epoch % _param.snapshot_epoch() != 0)
      && _epoch != _param.train_epoch()) {
    return;
  }
  generate_file_path();
  generate_datums();
  LOG(INFO) << "snapshot into file: " << _file_path;
  WriteDatumsIntoBinaryFile(_datums, _file_path, _param.output_model_file().type());
  LOG(INFO) << "snapshot done.";
}

template <typename Dtype>
void Cream<Dtype>::generate_learning_rate() {
  Dtype tmp = Dtype(1);
  LRParameter lr = _param.lr();
  const string& lr_policy = lr.lr_policy();
  if (lr_policy == "step") {
      tmp = pow(lr.step_gamma(), _epoch / lr.step_epoch());
  } else if (lr_policy == "exp") {
      tmp = pow(lr.exp_gamma(), _epoch);
  } else if (lr_policy == "inv") {
      tmp = pow(Dtype(1) + lr.inv_gamma() * _epoch, - lr.inv_power());
  } else if (lr_policy == "multistep") {
      tmp = pow(lr.multistep_gamma(), _epoch);
  } else if (lr_policy == "poly") {
      tmp = pow(Dtype(1) - (Dtype(_epoch) / Dtype(_param.train_epoch())),
        lr.ploy_power());
  } else if (lr_policy == "sigmoid") {
      tmp = Dtype(1) / (Dtype(1) + exp(-lr.sigmoid_gamma() * (Dtype(_epoch) -
          Dtype(lr.sigmoid_epoch()))));
  } else if (lr_policy != "fixed") {
      LOG(FATAL) << "Unknown learning rate policy: " << lr_policy;
  }

  _rate = lr.base_lr() * tmp;
}

template <typename Dtype>
void Cream<Dtype>::shuffle() {
  if (_param.shuffle()) {
    _candy->shuffle();
  }
}

template <typename Dtype>
void Cream<Dtype>::test() {
  CHECK(_param.has_test_file());
  test_one_epoch();

  LOG(INFO) << "Test " << type() << " output 1#: out_accuracy = "
      << _out_accuracy * 100.0 / _candy->test_shape().num << "%";
}

template <typename Dtype>
void Cream<Dtype>::maintain_top_n(const string& label, vector<pair<Dtype, string>>* top_n) {
  if (_param.sort_mode() == SolverParameter_SORT_MODE_ASC) {
    if (top_n->size() < this->_param.top()) {
        top_n->push_back(make_pair(_h_x, label));
    } else if (top_n->back().first > _h_x) {
      top_n->back() = make_pair(_h_x, label);
    } else {
      return;
    }

    for (int k = top_n->size() - 1; k - 1 >= 0 && top_n->at(k - 1).first > top_n->at(k).first; --k) {
      swap(top_n->at(k - 1), top_n->at(k));
    }
  } else if (_param.sort_mode() == SolverParameter_SORT_MODE_DESC) {
    if (top_n->size() < this->_param.top()) {
        top_n->push_back(make_pair(_h_x, label));
    } else if (top_n->back().first < _h_x) {
      top_n->back() = make_pair(_h_x, label);
    } else {
      return;
    }

    for (int k = top_n->size() - 1; k - 1 >= 0 && top_n->at(k - 1).first < top_n->at(k).first; --k) {
      swap(top_n->at(k - 1), top_n->at(k));
    }
  }
}

template <typename Dtype>
void Cream<Dtype>::maintain_acc(const vector<pair<Dtype, string>>& top_n,
								                const string& label,
								                long* acc) {
  for (size_t k = 0; k < top_n.size(); ++k) {
    if (top_n[k].second == label) {
      *acc += 1;
      break;
    }
  }
}

template <typename Dtype>
void Cream<Dtype>::train() {
  CHECK_GT(_param.top(), 0);

  LOG(INFO) << "Train " << type() << " model num : " << _candy->unique_label_size();
  for (this->_epoch = 1; this->_epoch <= this->_param.train_epoch(); ++this->_epoch) {
    generate_learning_rate();
    shuffle();
    train_one_epoch();
    test_one_epoch();
    display();
    snapshot();
  }
}

template <typename Dtype>
void Cream<Dtype>::test_one_epoch() {
  if (!this->_param.has_test_file()) {
    return;
  }

  CHECK_EQ(_candy->test_shape().num, _candy->test_data_size());
  CHECK_EQ(_candy->test_shape().num, _candy->test_label_size());
  CHECK_EQ(_candy->unique_label_size(), _candy->weight_size());

  _out_accuracy = 0;
  for (size_t i = 0; i < _candy->test_shape().num; ++i) {
    vector<pair<Dtype, string>> top_n;
    for (size_t j = 0; j < _candy->weight_size(); ++j) {
      h_x(_candy->test_data(i), _candy->weight(j));
      maintain_top_n(_candy->unique_label(j), &top_n);
    }

    maintain_acc(top_n, _candy->test_label(i), &_out_accuracy);
  }
}

template <typename Dtype>
void Cream<Dtype>::h_x(size_t idx_x, size_t idx_w) {
  CHECK_GT(_candy->data_size(), idx_x);
  CHECK_GT(_candy->weight_size(), idx_w);

  h_x(_candy->data(idx_x), _candy->weight(idx_w));
}

template <typename Dtype>
void Cream<Dtype>::h_x(const vector<Dtype>& data, const vector<Dtype>& weight) {
  _h_x = Calculate_H_X(data, weight, _param.h_x_policy(), Dtype(_param.lambda()));
}

template <typename Dtype>
bool Cream<Dtype>::is_show(int epoch) {
  return epoch > 0 && _epoch % epoch == 0;
}

template <typename Dtype>
void Cream<Dtype>::show_title() {
  if (is_show(this->_param.loss_epoch()) || is_show(this->_param.test_epoch())) {
    LOG(INFO) << "Train epoch: " << this->_epoch;
  }
}

template <typename Dtype>
void Cream<Dtype>::display() {
  int num = 0;
  show_title();
  show_lr(&num);
  show_loss(&num);
  show_acc(&num);
}

template <typename Dtype>
void Cream<Dtype>::show_lr(int* num) {
  if (is_show(this->_param.loss_epoch()) || is_show(this->_param.test_epoch())) {
    LOG(INFO) << "    Train " << type() << " output " << ++(*num) << "#: lr = " << _rate;
  }
}

template <typename Dtype>
void Cream<Dtype>::show_loss(int *num) {
  if (is_show(this->_param.loss_epoch()) || is_show(this->_param.test_epoch())) {
    LOG(INFO) << "    Train " << type() << " output " << ++(*num) << "#: loss = "
        << _loss / _candy->shape().num / _candy->unique_label_size();
  }
}

template <typename Dtype>
void Cream<Dtype>::show_acc(int *num) {
  if (is_show(this->_param.test_epoch())) {
    LOG(INFO) << "    Train " << type() << " output " << ++(*num) << "#: in_accuracy = "
        << _in_accuracy * 100.0 / _candy->shape().num << "%";
    if (this->_param.has_test_file()) {
      LOG(INFO) << "    Test " << type() << " output " << ++(*num) << "#: out_accuracy = "
        << _out_accuracy * 100.0 / _candy->test_shape().num << "%";
    }
  }
}

INSTANTIATE_CLASS(Cream);

}  // namespace cream
