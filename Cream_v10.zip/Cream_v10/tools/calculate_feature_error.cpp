#include <string>
#include <algorithm>
#include <cmath>
#include <glog/logging.h>
#include <boost/scoped_ptr.hpp>

#include "cream/proto/cream.pb.h"
#include "cream/common.h"
#include "cream/util/db.h"

using namespace std;
using namespace cream;
using boost::scoped_ptr;


DEFINE_string(feature_1, "",
    "The input feature_1 file path.");
DEFINE_string(feature_1_type, "leveldb",
    "The input feature_1 file type {leveldb/lmdb}.");
DEFINE_bool(is_normalize_1, true,
    "The flag for normalize(Sigmoid).");

DEFINE_string(feature_2, "",
    "The input feature_2 file path.");
DEFINE_string(feature_2_type, "leveldb",
    "The input feature_2 file type {leveldb/lmdb}.");
DEFINE_bool(is_normalize_2, false,
    "The flag for normalize(Sigmoid).");

DEFINE_string(mode, "Euclidean",
    "Similarity mode{Euclidean/Manhattan/Minkowski/Consine/Linear/Logistic}.");
DEFINE_double(lambda, 0, "Minkowski lambda.");

DEFINE_string(output_1, "",
    "The output file path.");
DEFINE_string(output_1_type, "leveldb",
    "The output file type {leveldb/lmdb}.");

DEFINE_string(output_2, "",
    "The output_2 file path.");
DEFINE_string(output_2_type, "leveldb",
    "The output_2 file type {leveldb/lmdb}.");

struct Point {
  int height;
  int width;
  int channels;
  string label;
  string path;
  vector<float> feature;
};

vector<Point> read_feature(const string& feature_type,
                          const string& feature_path,
                          bool is_normalize) {
  // Read feature.
  scoped_ptr<db::DB> feature_db(db::GetDB(feature_type));
  feature_db->Open(feature_path, db::READ);
  scoped_ptr<db::Cursor> feature_cursor(feature_db->NewCursor());
  vector<Point> ps;
  while (feature_cursor->valid()) {
    Datum datum;
    datum.ParseFromString(feature_cursor->value());
    Point p;
    for (size_t i = 0; i < datum.float_data_size(); ++i) {
      if (is_normalize) {
        p.feature.push_back(Sigmoid(datum.float_data(i)));
      } else {
        p.feature.push_back(datum.float_data(i));
      }
    }

    p.label = datum.img_label();
    p.path = datum.name();
    p.height = datum.height();
    p.width = datum.width();
    p.channels = datum.channels();

    ps.push_back(p);

    feature_cursor->Next();
  }

  return ps;
}

void write_feature(const string& output_type,
                  const string& output_path,
                  const vector<Point>& ps) {
  if (output_path.empty()) {
    return;
  }

  // Create output DB.
  scoped_ptr<db::DB> output_db(db::GetDB(output_type));
  output_db->Open(output_path, db::NEW);
  scoped_ptr<db::Transaction> txn(output_db->NewTransaction());
  size_t count = 0;
  for (size_t i = 0; i < ps.size(); ++i) {
    Datum datum;
    for (size_t j = 0; j < ps[i].feature.size(); ++j) {
      datum.add_float_data(ps[i].feature[j]);
    }
    datum.set_img_label(ps[i].label);
    datum.set_name(ps[i].path);
    datum.set_width(ps[i].width);
    datum.set_height(ps[i].height);
    datum.set_channels(ps[i].channels);

    // Put in output db.
    string out;
    CHECK(datum.SerializeToString(&out));
    txn->Put(to_string(count++), out);
    if (count % 1000 == 0) {
      txn->Commit();
      txn.reset(output_db->NewTransaction());
    }
  }

  if (count % 1000 != 0) {
    txn->Commit();    
  }
  output_db->Close();
}

int main(int argc, char** argv) {
  // Usage message.
  gflags::SetUsageMessage("Test model.\n"
    "Usage: calculate_feature_error <args>\n\n"
	  "args:\n"
	  "[FLAGS_FEATURE_1] [FLAGS_FEATURE_1_TYPE] [FLAGS_IS_NORMALIZE_1]"
    "[FLAGS_FEATURE_2] [FLAGS_FEATURE_2_TYPE] [FLAGS_IS_NORMALIZE_2]"
    "[FLAGS_MODE] [FLAGS_LAMBDA]"
    "[FLAGS_OUTPUT_1] [FLAGS_OUTPUT_1_TYPE]"
    "[FLAGS_OUTPUT_2] [FLAGS_OUTPUT_2_TYPE]");

  gflags::ParseCommandLineFlags(&argc, &argv, true);

  if (argc != 1) {
    gflags::ShowUsageWithFlagsRestrict(argv[0], "tools/calculate_feature_error");
    return 1;
  }

  // Read feature_1.
  vector<Point> ps1 = read_feature(FLAGS_feature_1_type, FLAGS_feature_1, FLAGS_is_normalize_1);
  // Read feature_2.
  vector<Point> ps2 = read_feature(FLAGS_feature_2_type, FLAGS_feature_2, FLAGS_is_normalize_2);

  CHECK_EQ(ps1.size(), ps2.size());
  CHECK_GT(ps1.size(), 0);

  float sum = 0;
  for (size_t i = 0; i < ps1.size(); ++i) {
    sum += Calculate_H_X(ps1[i].feature, ps2[i].feature, FLAGS_mode, float(FLAGS_lambda));
  }
  LOG(INFO) << "Feature error: " << sum / ps1.size();

  write_feature(FLAGS_output_1_type, FLAGS_output_1, ps1);
  write_feature(FLAGS_output_2_type, FLAGS_output_2, ps2);

  LOG(INFO) << "done.";

  return 0;
}
