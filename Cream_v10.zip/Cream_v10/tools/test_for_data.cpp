#include <string>
#include <glog/logging.h>
#include <boost/scoped_ptr.hpp>

#include "cream/proto/cream.pb.h"
#include "cream/util/db.h"

using namespace cream;
using boost::scoped_ptr;

DEFINE_string(input, "/home/good/Datasets/Consumer-to-shop/128/train_features_14342_fc128_leveldb",
    "The input file path.");
DEFINE_string(input_type, "leveldb",
    "The input file type {leveldb/lmdb}.");

int main(int argc, char** argv) {
  // Usage message.
  gflags::SetUsageMessage("Test data\n"
      "Usage: test_for_data <args>\n\n"
	  "args:\n"
	  "[FLAGS_INPUT] [FLAGS_INPUT_TYPE]");

  gflags::ParseCommandLineFlags(&argc, &argv, true);

  if (argc != 1) {
    gflags::ShowUsageWithFlagsRestrict(argv[0], "tools/test_for_data");
    return 1;
  }

  scoped_ptr<db::DB> input_db(db::GetDB(FLAGS_input_type));
  input_db->Open(FLAGS_input, db::READ);
  scoped_ptr<db::Cursor> cursor(input_db->NewCursor());

  LOG(INFO) << "Starting Iteration";
  int count = 0;
  while (cursor->valid()) {
    Datum datum;
    datum.ParseFromString(cursor->value());
    LOG(INFO) << datum.channels();
    LOG(INFO) << datum.width();
    LOG(INFO) << datum.height();
    LOG(INFO) << datum.img_label();
    LOG(INFO) << datum.name();

    for (size_t i = 0; i < datum.float_data_size(); ++i) {
      LOG(INFO) << datum.float_data(i);
    }

    break;
    cursor->Next();
  }

  LOG(INFO) << "done.";

  return 0;
}
