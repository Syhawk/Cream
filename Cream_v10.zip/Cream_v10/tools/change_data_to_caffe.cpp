#include <string>
#include <glog/logging.h>
#include <boost/scoped_ptr.hpp>

#include "cream/proto/cream.pb.h"
#include "cream/util/db.h"

using namespace cream;
using boost::scoped_ptr;


DEFINE_string(input, "",
    "The input file path.");
DEFINE_string(input_type, "leveldb",
    "The input file type {leveldb/lmdb}.");
DEFINE_string(output, "",
    "The output lmdb file path.");
DEFINE_string(output_type, "lmdb",
    "The output file type {leveldb/lmdb}.");

int main(int argc, char** argv) {
  // Usage message.
  gflags::SetUsageMessage("Change data to caffe data\n"
      "Usage: change_data_to_caffe <args>\n\n"
	  "args:\n"
	  "[FLAGS_INPUT] [FLAGS_INPUT_TYPE] [FLAGS_OUTPUT] [FLAGS_OUTPUT_TYPE]");

  gflags::ParseCommandLineFlags(&argc, &argv, true);

  if (argc != 1) {
    gflags::ShowUsageWithFlagsRestrict(argv[0], "tools/change_data_to_caffe");
    return 1;
  }

  scoped_ptr<db::DB> input_db(db::GetDB(FLAGS_input_type));
  input_db->Open(FLAGS_input, db::READ);
  scoped_ptr<db::Cursor> cursor(input_db->NewCursor());

  // Create new DB
  scoped_ptr<db::DB> output_db(db::GetDB(FLAGS_output_type));
  output_db->Open(FLAGS_output, db::NEW);
  scoped_ptr<db::Transaction> txn(output_db->NewTransaction());

  LOG(INFO) << "Starting Iteration";
  int count = 0;
  while (cursor->valid()) {
    Datum datum;
    datum.ParseFromString(cursor->value());
    datum.clear_data();
    string str = "";
    for (size_t i = 0; i < datum.float_data_size(); ++i) {
      str += char((uint8_t)(datum.float_data(i) * 255 - 128));
    }
    datum.set_data(str);
    datum.clear_float_data();

    // Put in output db
    string out;
    CHECK(datum.SerializeToString(&out));
    txn->Put(datum.img_label(), out);
    ++count;
    if (count % 10000 == 0) {
      txn->Commit();
      txn.reset(output_db->NewTransaction());
      LOG(INFO) << "Processed " << count << " files.";
    }
    cursor->Next();
  }

  if (count % 10000 != 0) {
    txn->Commit();
    LOG(INFO) << "Processed " << count << " files.";
  }
  output_db->Close();

  LOG(INFO) << "done.";

  return 0;
}
