#include <string>
#include <glog/logging.h>

#include "cream/common.h"
#include "cream/model_test.h"
#include "cream/similarity/hashcode_model_test.h"
#include "cream/similarity/hashcode_paper_model_test.h"

using namespace std;
using namespace cream;


DEFINE_string(feature, "",
    "The input feature file path.");
DEFINE_string(feature_type, "leveldb",
    "The input feature file type {leveldb/lmdb}.");
DEFINE_string(model, "",
    "The input model file path.");
DEFINE_string(model_type, "leveldb",
    "The input model file type {leveldb/lmdb}.");

DEFINE_string(test_feature, "",
    "The input test feature file path.");
DEFINE_string(test_feature_type, "lmdb",
    "The input test feature file type {leveldb/lmdb}.");

DEFINE_int32(top_n, 1, "The top n.");
DEFINE_string(filter, "", "Feature filter some imgs.");

DEFINE_string(space_cut_mode, "UseLabel",
    "Similarity mode{UseLabel/Euclidean/Manhattan/Minkowski/Consine/Linear/Logistic}.");
DEFINE_double(space_cut_lambda, 0, "Minkowski lambda.");
DEFINE_string(space_cut_sort_mode, "ASC", "Space cut mode{ASC/DESC}");

DEFINE_string(space_mode, "Euclidean",
    "Similarity mode{Euclidean/Manhattan/Minkowski/Consine/Linear/Logistic}.");
DEFINE_double(space_lambda, 0, "Minkowski lambda.");
DEFINE_string(space_sort_mode, "ASC", "Space cut mode{ASC/DESC}");

DEFINE_string(top_n_mode, "Euclidean",
    "Similarity mode{Euclidean/Manhattan/Minkowski/Consine/Linear/Logistic}.");
DEFINE_double(top_n_lambda, 0, "Minkowski lambda.");
DEFINE_string(top_n_sort_mode, "ASC", "Space cut mode{ASC/DESC}");

DEFINE_string(model_name, "Hashcode",
    "Model name{Hashcode/KMeans/HashcodePaper/Logistic}");

DEFINE_string(output, "",
    "The output file path.");
DEFINE_string(output_type, "leveldb",
    "The output file type {leveldb/lmdb}.");


int main(int argc, char** argv) {
  // Usage message.W
  gflags::SetUsageMessage("Test model.\n"
    "Usage: test_model <args>\n\n"
	  "args:\n"
	  "[FLAGS_FEATURE] [FLAGS_FEATURE_TYPE]"
    "[FLAGS_MODEL] [FLAGS_MODEL_TYPE]"
    "[FLAGS_TEST_FEATURE] [FLAGS_TEST_FEATURE_TYPE]"
    "[FLAGS_TOP_N] [FLAGS_FILTER]"
    "[FLAGS_SPACE_CUT_MODE] [FLAGS_SPACE_CUT_LAMBDA] [FLAGS_SPACE_CUT_SORT_MODE]"
    "[FLAGS_SPACE_MODE] [FLAGS_SPACE_LAMBDA] [FLAGS_SPACE_SORT_MODE]"
    "[FLAGS_TOP_N_MODE] [FLAGS_TOP_N_LAMBDA] [FLAGS_TOP_N_SORT_MODE]"
    "[FLAGS_MODEL_NAME]"
    "[FLAGS_OUTPUT] [FLAGS_OUTPUT_TYPE]");

  gflags::ParseCommandLineFlags(&argc, &argv, true);

  if (argc != 1) {
    gflags::ShowUsageWithFlagsRestrict(argv[0], "tools/test_model");
    return 1;
  }

  ModelTest* model_test;
  if (FLAGS_model_name == "Logistic" || FLAGS_model_name == "KMeans") {
    model_test = new ModelTest();
  } else if (FLAGS_model_name == "Hashcode") {
    model_test = new HashcodeModelTest();
  } else if (FLAGS_model_name == "HashcodePaper") {
    model_test = new HashcodePaperModelTest();
  } else {
    LOG(ERROR) << "Model name: "<< FLAGS_model_name << "error.";
    exit(0);
  }

  // Read model.
  model_test->read_model(FLAGS_model, FLAGS_model_type);
  // Read feature.
  model_test->read_feature(FLAGS_feature, FLAGS_feature_type, FLAGS_filter,
      FLAGS_space_cut_mode, float(FLAGS_space_cut_lambda), FLAGS_space_cut_sort_mode);
  // Read test feature.
  model_test->read_test_feature(FLAGS_test_feature, FLAGS_test_feature_type);
  // Test.
  model_test->test(FLAGS_top_n, FLAGS_space_mode, FLAGS_space_lambda,
      FLAGS_space_sort_mode, FLAGS_top_n_mode, FLAGS_top_n_lambda, FLAGS_top_n_sort_mode);
  // Write into binary file.
  model_test->write_datums(FLAGS_output, FLAGS_output_type);

  return 0;
}
