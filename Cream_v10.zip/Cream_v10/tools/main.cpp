#include <string>
#include <exception> 
#include <unordered_map>
#include <glog/logging.h>
#include <boost/shared_ptr.hpp>

#include "cream/proto/cream.pb.h"
#include "cream/common.h"
#include "cream/cream.h"
#include "cream/cream_factory.hpp"

using cream::Cream;
using cream::CreamRegistry;
using cream::GlobalInit;
using cream::string;
using cream::Message;
using cream::SolverParameter;
using std::unordered_map;
using std::exception;
using boost::shared_ptr;

DEFINE_string(solver, "",
    "The solver definition protocol buffer text file.");

// A simple registry for cream commands.
typedef void (*BrewFunction)();
typedef unordered_map<string, BrewFunction> BrewMap;
BrewMap g_brew_map;

#define RegisterBrewFunction(func) \
namespace { \
class __Registerer_##func { \
public: /* NOLINT */ \
  __Registerer_##func() { \
    g_brew_map[#func] = &func; \
  } \
}; \
__Registerer_##func g_registerer_##func; \
}

static BrewFunction GetBrewFunction(const string& name) {
  if (g_brew_map.count(name)) {
    return g_brew_map[name];
  } else {
    LOG(ERROR) << "Available cream actions:";
    for (BrewMap::iterator it = g_brew_map.begin();
         it != g_brew_map.end(); ++it) {
      LOG(ERROR) << "\t" << it->first;
    }
    LOG(FATAL) << "Unknown action: " << name;
    return NULL;  // not reachable, just to suppress old compiler warnings.
  }
}

// Train / Finetune a model.
void train() {
  CHECK_GT(FLAGS_solver.size(), 0) << "Need a solver definition to train.";

  SolverParameter solver_param;
  ReadSolverParamsFromTextFileOrDie(FLAGS_solver, &solver_param);
  shared_ptr<Cream<float>>
      cream(CreamRegistry<float>::CreateCream(solver_param));

  cream->init();
  LOG(INFO) << "Starting Optimization.";
  cream->train();
  LOG(INFO) << "Optimization Done.";
}
RegisterBrewFunction(train);

// Test: score a model.
void test() {
  CHECK_GT(FLAGS_solver.size(), 0) << "Need a solver definition to train.";

  SolverParameter solver_param;
  ReadSolverParamsFromTextFileOrDie(FLAGS_solver, &solver_param);
  shared_ptr<Cream<float>>
      cream(CreamRegistry<float>::CreateCream(solver_param));

  cream->init();
  LOG(INFO) << "Starting test.";
  cream->test();
  LOG(INFO) << "Test Done.";
}
RegisterBrewFunction(test);

int main(int argc, char** argv) {
  // Print output to stderr (while still logging).
  FLAGS_alsologtostderr = 1;
  // Usage message.
  gflags::SetUsageMessage("command line brew\n"
	  "Usage: main <command> <args>\n\n"
	  "command:\n"
	  "  train           train a model\n"
	  "  test            score a model\n"
	  "args:\n"
	  "[FLAG_SOLVER]");

  // Run tool or show usage.
  GlobalInit(&argc, &argv);

  if (argc == 2) {
    try {
	  GetBrewFunction(string(argv[1]))();
    } catch (exception& e) {
      LOG(ERROR) << e.what();
    }
  } else {
  	gflags::ShowUsageWithFlagsRestrict(argv[0], "tools/main");
  }

  return 0;
}
