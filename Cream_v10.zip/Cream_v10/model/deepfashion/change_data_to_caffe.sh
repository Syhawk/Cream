#!/usr/bin/env sh

TOOLS=build/tools
#INPUT=/home/silent-gpu/Datasets/DeepFashion/Consumer-to-shop/48/train_features_3332_fc8_encode_leveldb
#OUTPUT=/home/silent-gpu/Datasets/DeepFashion/Consumer-to-shop/48/train_features_3332_fc8_encode_lmdb
INPUT=/home/silent-gpu/Datasets/yahoo-shoes-image/1024/train_features_4443_fc8_encode_leveldb
OUTPUT=/home/silent-gpu/Datasets/yahoo-shoes-image/1024/train_features_4443_fc8_encode_lmdb
INPUT_TYPE=leveldb
OUTPUT_TYPE=lmdb

if [ ! -d "$INPUT" ]; then
  echo "Error: INPUT is not a path to a file: $INPUT"
  exit 1
fi

if [ -d $OUTPUT ]; then
    rm -rf $OUTPUT
fi

echo "Change to caffe data..."

$TOOLS/change_data_to_caffe \
    --input=$INPUT \
    --input_type=$INPUT_TYPE \
    --output=$OUTPUT \
    --output_type=$OUTPUT_TYPE

#INPUT=/home/silent-gpu/Datasets/DeepFashion/Consumer-to-shop/48/test_features_2469_fc8_encode_leveldb
#OUTPUT=/home/silent-gpu/Datasets/DeepFashion/Consumer-to-shop/48/test_features_2469_fc8_encode_lmdb
INPUT=/home/silent-gpu/Datasets/yahoo-shoes-image/1024/test_features_70_fc8_encode_leveldb
OUTPUT=/home/silent-gpu/Datasets/yahoo-shoes-image/1024/test_features_70_fc8_encode_lmdb

if [ ! -d "$INPUT" ]; then
  echo "Error: INPUT is not a path to a file: $INPUT"
  exit 1
fi

if [ -d $OUTPUT ]; then
    rm -rf $OUTPUT
fi

$TOOLS/change_data_to_caffe \
    --input=$INPUT \
    --input_type=$INPUT_TYPE \
    --output=$OUTPUT \
    --output_type=$OUTPUT_TYPE

echo "Done."
