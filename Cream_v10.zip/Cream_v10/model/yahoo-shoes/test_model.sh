#!/usr/bin/env sh

TOOLS=build/tools
FEATURE=/home/good/Datasets/yahoo-shoes-v2/128/train_features_3652_fc128_leveldb_bak
FEATURE_TYPE=leveldb

MODEL=/home/good/Datasets/yahoo-shoes-v2/128/test_937_fc128_bak_use_mean_value_Hashcode_epoch_1_leveldb.creammodel
MODEL_TYPE=leveldb

TEST_FEATURE=/home/good/Datasets/yahoo-shoes-v2/128/test_features_937_fc128_leveldb_bak
TEST_FEATURE_TYPE=leveldb

TOP_N=50
FILTER=comsumer_
#UseLabel Manhattan Euclidean Cosine
SPACE_CUT_MODE=UseLabel
SPACE_CUT_LAMBDA=0
SPACE_CUT_SORT_MODE=ASC

SPACE_MODE=Manhattan
SPACE_LAMBDA=0
SPACE_SORT_MODE=ASC

TOP_N_MODE=Manhattan
TOP_N_LAMBDA=0
TOP_N_SORT_MODE=ASC

# Hashcode KMeans HashcodePaper Logistic
MODEL_NAME=HashcodePaper
OUTPUT=/home/good/Datasets/yahoo-shoes-v2/128/output/HashcodePaper_937_fc128_bak_use_mean_value_$SPACE_CUT_MODE\_$SPACE_MODE\_$TOP_N_MODE\_leveldb
OUTPUT_TYPE=leveldb

if [ ! -d "$FEATURE" ]; then
  echo "Error: FEATURE is not a path to a file: $FEATURE"
  exit 1
fi

if [ ! -d "$MODEL" ]; then
  echo "Error: MODEL is not a path to a file: $MODEL"
  exit 1
fi

if [ ! -d "$TEST_FEATURE" ]; then
  echo "Error: TEST_FEATURE is not a path to a file: $TEST_FEATURE"
  exit 1
fi

if [ -d $OUTPUT ]; then
    rm -rf $OUTPUT
fi

$TOOLS/test_model \
    --feature=$FEATURE \
    --feature_type=$FEATURE_TYPE \
    --model=$MODEL \
    --model_type=$MODEL_TYPE \
    --test_feature=$TEST_FEATURE \
    --test_feature_type=$TEST_FEATURE_TYPE \
    --top_n=$TOP_N \
    --filter=$FILTER \
    --space_cut_mode=$SPACE_CUT_MODE \
    --space_cut_lambda=$SPACE_CUT_LAMBDA \
    --space_cut_sort_mode=$SPACE_CUT_SORT_MODE \
    --space_mode=$SPACE_MODE \
    --space_lambda=$SPACE_LAMBDA \
    --space_sort_mode=$SPACE_SORT_MODE \
    --top_n_mode=$TOP_N_MODE \
    --top_n_lambda=$TOP_N_LAMBDA \
    --top_n_sort_mode=$TOP_N_SORT_MODE \
    --model_name=$MODEL_NAME \
    --output=$OUTPUT \
    --output_type=$OUTPUT_TYPE

