#!/usr/bin/env sh

TOOLS=build/tools
FEATURE_1=/home/good/Datasets/yahoo-shoes-v2/64/train_features_3652_fc64_leveldb
FEATURE_1_TYPE=leveldb
IS_NORMALIZE_1=true

FEATURE_2=/home/good/Datasets/yahoo-shoes-v2/64/train_features_3652_fc64_sigmoid_leveldb
FEATURE_2_TYPE=leveldb
IS_NORMALIZE_2=false

#MODE=Euclidean
MODE=Manhattan
LAMBDA=0

OUTPUT_1=/home/good/Datasets/yahoo-shoes-v2/64/train_features_3652_fc64_leveldb_bak
OUTPUT_1_TYPE=leveldb

#OUTPUT_2=/home/good/Datasets/yahoo-shoes-v2/64/train_features_3652_fc64_leveldb
#OUTPUT_2_TYPE=leveldb
#if [ -d $OUTPUT_2 ]; then
#    rm -rf $OUTPUT_2
#fi

if [ ! -d "$FEATURE_1" ]; then
  echo "Error: FEATURE_1 is not a path to a file: $FEATURE_1"
  exit 1
fi

if [ ! -d "$FEATURE_2" ]; then
  echo "Error: FEATURE_2 is not a path to a file: $FEATURE_2"
  exit 1
fi

if [ -d $OUTPUT_1 ]; then
    rm -rf $OUTPUT_1
fi

echo "Calculate feature error..."

$TOOLS/calculate_feature_error \
    --feature_1=$FEATURE_1 \
    --feature_1_type=$FEATURE_1_TYPE \
    --is_normalize_1=$IS_NORMALIZE_1 \
    --feature_2=$FEATURE_2 \
    --feature_2_type=$FEATURE_2_TYPE \
    --is_normalize_2=$IS_NORMALIZE_2 \
    --mode=$MODE \
    --lambda=$LAMBDA \
    --output_1=$OUTPUT_1 \
    --output_1_type=$OUTPUT_1_TYPE

echo "Done."
